import torch
from torch import nn
import torch.nn.functional as F


def disp2prob(disp, mindisp, maxdisp):
    B, C, H, W = disp.size()
    disp = torch.clamp(disp, min=mindisp, max=maxdisp)
    x0 = torch.floor(disp)
    x1 = x0 + 1

    x0_safe = torch.clamp(x0, min=mindisp, max=maxdisp)
    x1_safe = torch.clamp(x1, min=mindisp, max=maxdisp)

    wt_x0 = (x1 - disp) * torch.eq(x0, x0_safe).float()
    wt_x1 = (disp - x0) * torch.eq(x1, x1_safe).float()

    prob = torch.zeros((B, maxdisp+1-mindisp, H, W), device='cuda')
    prob.scatter_add_(1, x0_safe.long()-mindisp, wt_x0)
    prob.scatter_add_(1, x1_safe.long()-mindisp, wt_x1)

    return prob


def prob2disp(prob, normalize=True, mindisp=0, return_prob=False):
    # prob: density
    # normalize: if true, prob will be normalized via softmax
    if normalize:
        prob = F.softmax(prob, dim=1)

    B, D, H, W = prob.size()
    pr = prob.reshape(B, D, -1).permute(0, 2, 1)
    avg_pool = nn.AvgPool1d(kernel_size=2, stride=1, padding=0)
    max_pool = nn.MaxPool1d(kernel_size=D-1, stride=1, return_indices=True)
    out, indice = max_pool(avg_pool(pr))
    indice = indice.squeeze().reshape(B, H, W).unsqueeze(1)
    l_prob = torch.gather(prob, 1, indice)
    r_prob = torch.gather(prob, 1, indice + 1)
    l_prob_norm = l_prob / (l_prob + r_prob)
    disp = indice.float() + 1 - l_prob_norm
    disp = disp + mindisp

    if return_prob:
        out = out.squeeze().reshape(B, H, W).unsqueeze(1)
        return disp, out
    else:
        return disp