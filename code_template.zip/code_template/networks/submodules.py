# freda (todo) : 

import torch.nn as nn
import torch
import numpy as np 
from torch.autograd import Variable
import torch.nn.functional as F
from torch.autograd import Function
from torch.nn.modules.utils import _pair, _triple
#from correlation_package.modules.corr import Correlation1d # from PWC-Net


def consistent_padding_with_dilation(padding, dilation, dim=2):
    assert dim == 2 or dim == 3, 'Convolution layer only support 2D and 3D'
    if dim == 2:
        padding = _pair(padding)
        dilation = _pair(dilation)
    else:  # dim == 3
        padding = _triple(padding)
        dilation = _triple(dilation)

    padding = list(padding)
    for d in range(dim):
        padding[d] = dilation[d] if dilation[d] > 1 else padding[d]
    padding = tuple(padding)

    return padding, dilation


class ResBlock(nn.Module):
    def __init__(self, n_in, n_out, stride = 1):
        super(ResBlock, self).__init__()
        self.conv1 = nn.Conv2d(n_in, n_out, kernel_size=3, stride=stride, padding=1)
        self.bn1 = nn.BatchNorm2d(n_out)
        self.relu = nn.ReLU(inplace=True)
        self.conv2 = nn.Conv2d(n_out, n_out, kernel_size=3, padding=1)
        self.bn2 = nn.BatchNorm2d(n_out)

        if stride != 1 or n_out != n_in:
            self.shortcut = nn.Sequential(
                nn.Conv2d(n_in, n_out, kernel_size=1, stride = stride),
                nn.BatchNorm2d(n_out))
        else:
            self.shortcut = None

    def forward(self, x):
        residual = x
        if self.shortcut is not None:
            residual = self.shortcut(x)
        out = self.conv1(x)
        out = self.bn1(out)
        out = self.relu(out)
        out = self.conv2(out)
        out = self.bn2(out)
        
        out += residual
        out = self.relu(out)
        return out


class ResBlock_1x1(nn.Module):
    def __init__(self, n_in, n_out, stride=1):
        super(ResBlock_1x1, self).__init__()
        self.conv1 = nn.Conv2d(n_in, n_in, kernel_size=3, stride=stride, padding=1)
        self.bn1 = nn.BatchNorm2d(n_in)
        self.relu = nn.ReLU(inplace=True)
        self.conv2 = nn.Conv2d(n_in, n_out, kernel_size=1)
        self.bn2 = nn.BatchNorm2d(n_out)

        if stride != 1 or n_out != n_in:
            self.shortcut = nn.Sequential(
                nn.Conv2d(n_in, n_out, kernel_size=1, stride=stride),
                nn.BatchNorm2d(n_out))
        else:
            self.shortcut = None

    def forward(self, x):
        residual = x
        if self.shortcut is not None:
            residual = self.shortcut(x)
        out = self.conv1(x)
        out = self.bn1(out)
        out = self.relu(out)
        out = self.conv2(out)
        out = self.bn2(out)

        out += residual
        out = self.relu(out)
        return out


def conv(in_planes, out_planes, kernel_size=3, stride=1, use_bn=True):
    if use_bn:
        return nn.Sequential(
            nn.Conv2d(in_planes, out_planes, kernel_size=kernel_size, stride=stride, padding=(kernel_size-1)//2, bias=True),
            nn.BatchNorm2d(out_planes),
            nn.ReLU(inplace=True)
        )
    else:
        return nn.Sequential(
            nn.Conv2d(in_planes, out_planes, kernel_size=kernel_size, stride=stride, padding=(kernel_size-1)//2, bias=True),
            nn.ReLU(inplace=True)
        )

def i_conv(batchNorm, in_planes, out_planes, kernel_size=3, stride=1, bias = True):
    if batchNorm:
        return nn.Sequential(
            nn.Conv2d(in_planes, out_planes, kernel_size=kernel_size, stride=stride, padding=(kernel_size-1)//2, bias=bias),
            nn.BatchNorm2d(out_planes),
        )
    else:
        return nn.Sequential(
            nn.Conv2d(in_planes, out_planes, kernel_size=kernel_size, stride=stride, padding=(kernel_size-1)//2, bias=bias),
        )

def convbn(in_planes, out_planes, kernel_size, stride, pad, dilation):
    return nn.Sequential(nn.Conv2d(in_planes, out_planes, kernel_size=kernel_size, stride=stride, padding=dilation if dilation > 1 else pad, dilation = dilation, bias=False),
                         nn.BatchNorm2d(out_planes))


def convbn_3d(in_planes, out_planes, kernel_size, stride, pad):
    return nn.Sequential(nn.Conv3d(in_planes, out_planes, kernel_size=kernel_size, padding=pad, stride=stride,bias=False),
                         nn.BatchNorm3d(out_planes))


def predict_flow(in_planes):
    return nn.Conv2d(in_planes, 1, kernel_size=3, stride=1, padding=1, bias=False)


def deconv(in_planes, out_planes):
    return nn.Sequential(
        nn.ConvTranspose2d(in_planes, out_planes, kernel_size=4, stride=2, padding=1, bias=False),
        nn.ReLU(inplace=True)
    )


def convbn(in_planes, out_planes, kernel_size, stride, pad, dilation):
    return nn.Sequential(nn.Conv2d(in_planes, out_planes, kernel_size=kernel_size, stride=stride,
                                   padding=dilation if dilation > 1 else pad, dilation=dilation, bias=False),
                         nn.BatchNorm2d(out_planes))


class matchshifted(nn.Module):
    def __init__(self):
        super(matchshifted, self).__init__()

    def forward(self, left, right, shift):
        batch, filters, height, width = left.size()
        shifted_left  = F.pad(torch.index_select(left,  3, Variable(torch.LongTensor([i for i in range(shift,width)])).cuda()),(shift,0,0,0))
        shifted_right = F.pad(torch.index_select(right, 3, Variable(torch.LongTensor([i for i in range(width-shift)])).cuda()),(shift,0,0,0))
        out = torch.cat((shifted_left,shifted_right),1).view(batch,filters*2,1,height,width)
        return out


class disparityregression(nn.Module):
    def __init__(self, maxdisp):
        super(disparityregression, self).__init__()
        self.disp = Variable(torch.Tensor(np.reshape(np.array(range(maxdisp)),[1,maxdisp,1,1])).cuda(), requires_grad=False)

    def forward(self, x):
        disp = self.disp.repeat(x.size()[0],1,x.size()[2],x.size()[3])
        out = torch.sum(x*disp,1, keepdim=True)
        return out

def disparity_regression(x, maxdisp):
    assert len(x.shape) == 4
    disp_values = torch.arange(0, maxdisp, dtype=x.dtype, device=x.device)
    disp_values = disp_values.view(1, maxdisp, 1, 1)
    return torch.sum(x * disp_values, 1, keepdim=True)


def disparity_regression_stride(x, maxdisp):
    assert len(x.shape) == 4
    disp_values = torch.arange(0, maxdisp, dtype=x.dtype, device=x.device)
    disp_values = disp_values.view(1, maxdisp, 1, 1)
    return torch.sum(x * disp_values, 1, keepdim=True)


def conv_bn(batchNorm, in_planes, out_planes, kernel_size=3, stride=1, padding=1, dilation=1, bias=True):
    padding, dilation = consistent_padding_with_dilation(padding, dilation, dim=2)
    if batchNorm:
        return nn.Sequential(nn.Conv2d(in_planes, out_planes, kernel_size=kernel_size,
                                       stride=stride, padding=padding, dilation=dilation, bias=bias),
                             nn.BatchNorm2d(out_planes))
    else:
        return nn.Sequential(nn.Conv2d(in_planes, out_planes, kernel_size=kernel_size,
                                       stride=stride, padding=padding, dilation=dilation, bias=bias))


def conv_bn_relu(batchNorm, in_planes, out_planes, kernel_size=3, stride=1, padding=1, dilation=1, bias=True):
    padding, dilation = consistent_padding_with_dilation(padding, dilation, dim=2)
    if batchNorm:
        return nn.Sequential(nn.Conv2d(in_planes, out_planes, kernel_size=kernel_size, stride=stride,
                                       padding=padding, dilation=dilation, bias=bias),
                             nn.BatchNorm2d(out_planes),
                             nn.ReLU(inplace=True))
    else:
        return nn.Sequential(nn.Conv2d(in_planes, out_planes, kernel_size=kernel_size, stride=stride,
                                       padding=padding, dilation=dilation, bias=bias),
                             nn.ReLU(inplace=True))


class BasicBlock(nn.Module):
    expansion = 1

    def __init__(self, batchNorm, in_planes, out_planes, stride, downsample, padding, dilation):
        super(BasicBlock, self).__init__()
        self.conv1 = conv_bn_relu(batchNorm=batchNorm, in_planes=in_planes, out_planes=out_planes,
                                  kernel_size=3, stride=stride, padding=padding, dilation=dilation, bias=False)
        self.conv2 = conv_bn(batchNorm=batchNorm, in_planes=out_planes, out_planes=out_planes,
                             kernel_size=3, stride=1, padding=padding, dilation=dilation, bias=False)

        self.downsample = downsample
        self.stride = stride

    def forward(self, x):
        out = self.conv1(x)
        out = self.conv2(out)

        if self.downsample is not None:
            x = self.downsample(x)
        out += x

        return out


def conv3d_bn(batchNorm, in_planes, out_planes, kernel_size=3, stride=1, padding=1, dilation=1, bias=True):
    padding, dilation = consistent_padding_with_dilation(padding, dilation, dim=3)
    if batchNorm:
        return nn.Sequential(
            nn.Conv3d(
                in_planes, out_planes, kernel_size=kernel_size, stride=stride,
                padding=padding, dilation=dilation, bias=bias),
            nn.BatchNorm3d(out_planes),
        )
    else:
        return nn.Sequential(
            nn.Conv3d(
                in_planes, out_planes, kernel_size=kernel_size, stride=stride,
                padding=padding, dilation=dilation, bias=bias
            ),
        )


def conv3d_bn_relu(batchNorm, in_planes, out_planes, kernel_size=3, stride=1, padding=1, dilation=1, bias=True):
    padding, dilation = consistent_padding_with_dilation(padding, dilation, dim=3)
    if batchNorm:
        return nn.Sequential(
            nn.Conv3d(
                in_planes, out_planes, kernel_size=kernel_size, stride=stride,
                padding=padding, dilation=dilation, bias=bias),
            nn.BatchNorm3d(out_planes),
            nn.ReLU(inplace=True),
        )
    else:
        return nn.Sequential(
            nn.Conv3d(
                in_planes, out_planes, kernel_size=kernel_size, stride=stride,
                padding=padding, dilation=dilation, bias=bias
            ),
            nn.ReLU(inplace=True),
        )


def deconv3d_bn(batchNorm, in_planes, out_planes, kernel_size=4, stride=2, padding=1, output_padding=0, bias=True):
    if batchNorm:
        return nn.Sequential(
            nn.ConvTranspose3d(
                in_planes, out_planes, kernel_size=kernel_size, stride=stride,
                padding=padding, output_padding=output_padding, bias=bias),
            nn.BatchNorm3d(out_planes),
        )
    else:
        return nn.Sequential(
            nn.ConvTranspose3d(
                in_planes, out_planes, kernel_size=kernel_size, stride=stride,
                padding=padding, output_padding=output_padding, bias=bias
            ),
        )


class Hourglass(nn.Module):
    def __init__(self, in_planes, batch_norm=True):
        super(Hourglass, self).__init__()
        self.batch_norm = batch_norm

        self.conv1 = conv3d_bn_relu(
            self.batch_norm, in_planes, in_planes * 2,
            kernel_size=3, stride=2, padding=1, bias=False
        )

        self.conv2 = conv3d_bn(
            self.batch_norm, in_planes * 2, in_planes * 2,
            kernel_size=3, stride=1, padding=1, bias=False
        )

        self.conv3 = conv3d_bn_relu(
            self.batch_norm, in_planes * 2, in_planes * 2,
            kernel_size=3, stride=2, padding=1, bias=False
        )
        self.conv4 = conv3d_bn_relu(
            self.batch_norm, in_planes * 2, in_planes * 2,
            kernel_size=3, stride=1, padding=1, bias=False
        )
        self.conv5 = deconv3d_bn(
            self.batch_norm, in_planes * 2, in_planes * 2,
            kernel_size=3, padding=1, output_padding=1, stride=2, bias=False
        )
        self.conv6 = deconv3d_bn(
            self.batch_norm, in_planes * 2, in_planes,
            kernel_size=3, padding=1, output_padding=1, stride=2, bias=False
        )

    def forward(self, x, presqu, postsqu):
        # in:1/4, out:1/8
        out = self.conv1(x)
        # in:1/8, out:1/8
        pre = self.conv2(out)
        if postsqu is not None:
            pre = F.relu(pre + postsqu, inplace=True)
        else:
            pre = F.relu(pre, inplace=True)

        # in:1/8, out:1/16
        out = self.conv3(pre)
        # in:1/16, out:1/16
        out = self.conv4(out)

        # in:1/16, out:1/8
        if presqu is not None:
            post = F.relu(self.conv5(out) + presqu, inplace=True)
        else:
            post = F.relu(self.conv5(out) + pre, inplace=True)

        # in:1/8, out:1/4
        out = self.conv6(post)

        return out, pre, post



class tofp16(nn.Module):
    def __init__(self):
        super(tofp16, self).__init__()

    def forward(self, input):
        return input.half()


class tofp32(nn.Module):
    def __init__(self):
        super(tofp32, self).__init__()

    def forward(self, input):
        return input.float()


def init_deconv_bilinear(weight):
    f_shape = weight.size()
    heigh, width = f_shape[-2], f_shape[-1]
    f = np.ceil(width/2.0)
    c = (2 * f - 1 - f % 2) / (2.0 * f)
    bilinear = np.zeros([heigh, width])
    for x in range(width):
        for y in range(heigh):
            value = (1 - abs(x / f - c)) * (1 - abs(y / f - c))
            bilinear[x, y] = value
    weight.data.fill_(0.)
    for i in range(f_shape[0]):
        for j in range(f_shape[1]):
            weight.data[i,j,:,:] = torch.from_numpy(bilinear)


def save_grad(grads, name):
    def hook(grad):
        grads[name] = grad
    return hook


'''
def save_grad(grads, name):
    def hook(grad):
        grads[name] = grad
    return hook
import torch
from channelnorm_package.modules.channelnorm import ChannelNorm 
model = ChannelNorm().cuda()
grads = {}
a = 100*torch.autograd.Variable(torch.randn((1,3,5,5)).cuda(), requires_grad=True)
a.register_hook(save_grad(grads, 'a'))
b = model(a)
y = torch.mean(b)
y.backward()

'''

# output same as Correlation1D(max_displacement=max_disp, pad=max_disp, single_direction=-1, kernel_size=1)
class Py_Corr(nn.Module):
    def __init__(self, max_displacement=40, pad=40, single_direction=-1, kernel_size=1):
        super(Py_Corr, self).__init__()
        self.max_displacement = int(max_displacement)
        self.pad = int(pad)
        self.single_direction = int(single_direction)
        self.kernel_size = int(kernel_size)

    def forward(self, img_left, img_right):
        B, C, H, W = img_left.shape
        volume = img_left.new_zeros([B, self.max_displacement+1, H, W])
        for i in range(1, self.max_displacement+2):
                volume[:, self.max_displacement+1-i, :, i:] = (img_left[:, :, :, i:] * img_right[:, :, :, :-i]).mean(dim=1)
        volume = volume.contiguous()
        return volume


class Py_Corr_Attention(nn.Module):
    def __init__(self, max_displacement=40, pad=40, single_direction=-1, kernel_size=1, inplanes = 256):
        super(Py_Corr_Attention, self).__init__()
        self.max_displacement = int(max_displacement)
        self.pad = int(pad)
        self.single_direction = int(single_direction)
        self.kernel_size = int(kernel_size)
        self.maxpool = nn.AdaptiveAvgPool2d(1)
        self.fc1 = nn.Conv2d(inplanes, inplanes//4, 1)
        self.relu = nn.ReLU(inplace=True)
        self.fc2 = nn.Conv2d(inplanes//4, inplanes, 1)
        self.sigmoid = nn.Sigmoid()

    def forward(self, img_left, img_right):
        B, C, H, W = img_left.shape
        volume = img_left.new_zeros([B, self.max_displacement+1, H, W])
        for i in range(1, self.max_displacement+2):
            combine_feature = img_left[:, :, :, i:] * img_right[:, :, :, :-i]
            at_feature = self.maxpool(combine_feature)
            at_feature = self.fc1(at_feature)
            at_feature = self.relu(at_feature)
            at_feature = self.fc2(at_feature)
            at_feature = self.sigmoid(at_feature)
            volume[:, self.max_displacement+1-i, :, i:] = (combine_feature * at_feature).sum(dim=1)
        volume = volume.contiguous()
        return volume


class Py_Cat_Attention(nn.Module):
    def __init__(self, max_displacement=40, pad=40, single_direction=-1, kernel_size=1, inplanes = 512):
        super(Py_Cat_Attention, self).__init__()
        self.max_displacement = int(max_displacement)
        self.pad = int(pad)
        self.single_direction = int(single_direction)
        self.kernel_size = int(kernel_size)
        self.maxpool = nn.AdaptiveAvgPool2d(1)
        self.fc1 = nn.Conv2d(inplanes, inplanes//4, 1)
        self.relu = nn.ReLU(inplace=True)
        self.fc2 = nn.Conv2d(inplanes//4, inplanes, 1)
        self.sigmoid = nn.Sigmoid()

    def forward(self, img_left, img_right):
        B, C, H, W = img_left.shape
        volume = img_left.new_zeros([B, self.max_displacement+1, H, W])
        for i in range(1, self.max_displacement+2):
            cat_feature = torch.cat((img_left[:, :, :, i:], img_right[:, :, :, :-i]), 1)
            at_feature = self.maxpool(cat_feature)
            at_feature = self.fc1(at_feature)
            at_feature = self.relu(at_feature)
            at_feature = self.fc2(at_feature)
            at_feature = self.sigmoid(at_feature)
            volume[:, self.max_displacement+1-i, :, i:] = (cat_feature * at_feature).sum(dim=1)
        volume = volume.contiguous()
        return volume


class Correlation1D(Function):
    @staticmethod
    def backward(ctx, grad_output):
        return grad_output

    def forward(self, img_left, img_right, max_displacement, pad, single_direction, kernel_size):
        B, C, H, W = img_left.shape
        volume = img_left.new_zeros([B, max_displacement + 1, H, W])
        for i in range(1, max_displacement + 2):
            volume[:, max_displacement + 1 - i, :, i:] = (img_left[:, :, :, i:] * img_right[:, :, :, :-i]).mean(dim=1)
        volume = volume.contiguous()
        return volume

    @staticmethod
    def symbolic(g, img_left, img_right, max_displacement, pad, single_direction, kernel_size):
        return g.op("Correlation1D", img_left, img_right, max_displacement_i=max_displacement, pad_i=pad,
                    single_direction_i=single_direction, kernel_size_i=kernel_size)


class Corr(torch.nn.Module):
    def __init__(self, max_displacement=40, pad=40, single_direction=-1, kernel_size=1):
        super(Corr, self).__init__()
        self.max_displacement = int(max_displacement)
        self.pad = int(pad)
        self.single_direction = int(single_direction)
        self.kernel_size = int(kernel_size)

    def forward(self, img_left, img_right):
        return Correlation1D.apply(img_left, img_right, self.max_displacement, self.pad, self.single_direction,
                                   self.kernel_size)


# def build_corr(img_left, img_right, max_disp=40):
#     B, C, H, W = img_left.shape
#     volume = img_left.new_zeros([B, max_disp, H, W])
#     for i in range(max_disp):
#         if i > 0:
#             volume[:, i, :, i:] = (img_left[:, :, :, i:] * img_right[:, :, :, :-i]).mean(dim=1)
#         else:
#             volume[:, i, :, :] = (img_left[:, :, :, :] * img_right[:, :, :, :]).mean(dim=1)
#
#     volume = volume.contiguous()
#     return volume


def build_concat_volume(refimg_fea, targetimg_fea, maxdisp):
    B, C, H, W = refimg_fea.shape
    volume = refimg_fea.new_zeros([B, 2 * C, maxdisp, H, W])
    for i in range(maxdisp):
        if i > 0:
            volume[:, :C, i, :, i:] = refimg_fea[:, :, :, i:]
            volume[:, C:, i, :, i:] = targetimg_fea[:, :, :, :-i]
        else:
            volume[:, :C, i, :, :] = refimg_fea
            volume[:, C:, i, :, :] = targetimg_fea
    volume = volume.contiguous()
    return volume


def groupwise_correlation(fea1, fea2, num_groups):
    B, C, H, W = fea1.shape
    assert C % num_groups == 0
    channels_per_group = C // num_groups
    cost = (fea1 * fea2).view([B, num_groups, channels_per_group, H, W]).mean(dim=2)
    assert cost.shape == (B, num_groups, H, W)
    return cost


def build_gwc_volume(refimg_fea, targetimg_fea, maxdisp, num_groups):
    B, C, H, W = refimg_fea.shape
    volume = refimg_fea.new_zeros([B, num_groups, maxdisp, H, W])
    for i in range(maxdisp):
        if i > 0:
            volume[:, :, i, :, i:] = groupwise_correlation(refimg_fea[:, :, :, i:], targetimg_fea[:, :, :, :-i],
                                                           num_groups)
        else:
            volume[:, :, i, :, :] = groupwise_correlation(refimg_fea, targetimg_fea, num_groups)
    volume = volume.contiguous()
    return volume


