import torch
import torch.nn as nn
import torch.utils.data
from torch.autograd import Variable
import torch.nn.functional as F
import math
from .submodule import *


def convbn(in_planes, out_planes, kernel_size, stride, pad=0, dilation=1):
    return nn.Sequential(nn.Conv2d(in_planes, out_planes,kernel_size=kernel_size,
                                   stride=stride, padding=dilation if dilation > 1 else pad, 
                                   dilation=dilation, bias=False),
                         nn.BatchNorm2d(out_planes))


class BasicBlock(nn.Module):
    expansion = 1

    def __init__(self, inplanes, planes, stride, downsample, pad, dilation):
        super(BasicBlock, self).__init__()

        self.conv1 = nn.Sequential(convbn(inplanes, planes, 3, stride, pad, dilation),
                                   nn.ReLU(inplace=True))

        self.conv2 = convbn(planes, planes, 3, 1, pad, dilation)

        self.downsample = downsample
        self.stride = stride

    def forward(self, x):
        out = self.conv1(x)
        out = self.conv2(out)

        if self.downsample is not None:
            x = self.downsample(x)

        out = x + out

        return out


class feature_extraction(nn.Module):
    def __init__(self):
        super(feature_extraction, self).__init__()
        self.inplanes = 16
        self.firstconv = nn.Sequential(convbn(3, 16, 3, 2, 1, 1),
                                       nn.ReLU(inplace=True),
                                       convbn(16, 16, 3, 1, 1, 1),
                                       nn.ReLU(inplace=True))

        self.layer1 = self._make_layer(BasicBlock, 16, 3, 2, 1, 1)
        self.layer2 = self._make_layer(BasicBlock, 16, 2, 1, 1, 1)

        self.finalconv = nn.Sequential(convbn(16, 32, 3, 1, 1, 1),
                                       nn.ReLU(inplace=True),
                                       nn.Conv2d(32, 32, kernel_size=1, padding=0, stride=1, bias=False)
                                       )

    def _make_layer(self, block, planes, blocks, stride, pad, dilation):
        downsample = None
        if stride != 1 or self.inplanes != planes * block.expansion:
            downsample = nn.Sequential(nn.Conv2d(self.inplanes, planes * block.expansion,
                                                 kernel_size=1, stride=stride, bias=False),
                                       nn.BatchNorm2d(planes * block.expansion))

        layers = []
        layers.append(block(self.inplanes, planes, stride, downsample, pad, dilation))
        self.inplanes = planes * block.expansion
        for _ in range(1, blocks):
            layers.append(block(self.inplanes, planes, 1, None, pad, dilation))

        return nn.Sequential(*layers)

    def forward(self, x):
        output = self.firstconv(x)
        output = self.layer1(output)
        output = self.layer2(output)
        output_feature = self.finalconv(output)
        return output_feature


class hourglass(nn.Module):
    def __init__(self, inplanes):
        super(hourglass, self).__init__()

        self.conv1 = nn.Sequential(convbn(inplanes, inplanes * 2, kernel_size=3, stride=2, pad=1),
                                   nn.ReLU(inplace=True))

        self.conv2 = nn.Sequential(convbn(inplanes * 2, inplanes * 2, kernel_size=3, stride=1, pad=1),
                                   nn.ReLU(inplace=True))

        self.conv3 = nn.Sequential(convbn(inplanes * 2, inplanes * 2, kernel_size=3, stride=2, pad=1),
                                   nn.ReLU(inplace=True))

        self.conv4 = nn.Sequential(convbn(inplanes * 2, inplanes * 2, kernel_size=3, stride=1, pad=1),
                                   nn.ReLU(inplace=True))
        self.conv5 = nn.Sequential(nn.ConvTranspose2d(inplanes * 2, inplanes * 2, kernel_size=3, padding=1, 
                                                      output_padding=1, stride=2, bias=False),
                                   nn.BatchNorm2d(inplanes * 2),
                                   nn.ReLU(inplace=True))  # +conv2

        self.conv6 = nn.Sequential(nn.ConvTranspose2d(inplanes * 2, inplanes, kernel_size=3, padding=1, 
                                                      output_padding=1, stride=2, bias=False),
                                   nn.BatchNorm2d(inplanes),
                                   nn.ReLU(inplace=True))  # +x

        self.conv7 = nn.Sequential(convbn(inplanes * 4, inplanes * 2, kernel_size=3, stride=1, pad=1),
                                   nn.ReLU(inplace=True))

        self.conv8 = nn.Sequential(convbn(inplanes * 2, inplanes, kernel_size=3, stride=1, pad=1),
                                   nn.ReLU(inplace=True))

    def forward(self, x):

        out = self.conv1(x)  # in:1/4 out:1/8
        pre = self.conv2(out)  # in:1/8 out:1/8

        out = self.conv3(pre)  # in:1/8 out:1/16
        out = self.conv4(out)  # in:1/16 out:1/16

        post = self.conv7(torch.cat([self.conv5(out), pre], 1))

        out = self.conv8(torch.cat([x, self.conv6(post)], 1))  # in:1/8 out:1/4
        return out


class EasyBaseSemIndiv(nn.Module):
    def __init__(self, maxdisp):
        super(EasyBaseSemIndiv, self).__init__()

        self.maxdisp = maxdisp

        self.feature_extraction = feature_extraction()
        self.cost_aggs = nn.Sequential(convbn(int(self.maxdisp // 4), 32, 1, 1, 0),
                                       nn.ReLU(inplace=True),
                                       convbn(32, 32, 3, 1, 1),
                                       nn.ReLU(inplace=True))

        self.dres0 = nn.Sequential(convbn(64, 32, 3, 1, 1),
                                   nn.ReLU(inplace=True),
                                   convbn(32, 32, 3, 1, 1),
                                   nn.ReLU(inplace=True))

        self.dres1 = nn.Sequential(convbn(32, 32, 3, 1, 1),
                                   nn.ReLU(inplace=True),
                                   convbn(32, 32, 3, 1, 1))

        self.down2 = nn.Sequential(convbn(64, 32, 3, 1, 1),
                                   nn.ReLU(inplace=True),
                                   convbn(32, 32, 3, 1, 1))

        self.down3 = nn.Sequential(convbn(96, 32, 3, 1, 1),
                                   nn.ReLU(inplace=True),
                                   convbn(32, 32, 3, 1, 1))

        self.dres2 = hourglass(32)

        self.dres3 = hourglass(32)

        self.dres4 = hourglass(32)

        # self.classif1 = nn.Sequential(convbn(32, 32, 3, 1, 1),
        #                               nn.ReLU(inplace=True),
        #                               nn.Conv2d(32, self.maxdisp // 4, kernel_size=3,
        #                               padding=1, stride=1, bias=False))
        #
        # self.classif2 = nn.Sequential(convbn(32, 32, 3, 1, 1),
        #                               nn.ReLU(inplace=True),
        #                               nn.Conv2d(32, self.maxdisp // 4, kernel_size=3,
        #                               padding=1, stride=1, bias=False))

        self.classif3 = nn.Sequential(convbn(32, 32, 3, 1, 1),
                                      nn.ReLU(inplace=True),
                                      nn.Conv2d(32, self.maxdisp // 4, kernel_size=3,
                                                padding=1, stride=1, bias=False))

        for m in self.modules():
            if isinstance(m, nn.Conv2d):
                n = m.kernel_size[0] * m.kernel_size[1] * m.out_channels
                m.weight.data.normal_(0, math.sqrt(2. / n))
            elif isinstance(m, nn.ConvTranspose2d):
                n = m.kernel_size[0] * m.kernel_size[1] * m.out_channels
                m.weight.data.normal_(0, math.sqrt(2. / n))
            elif isinstance(m, nn.Conv3d):
                n = m.kernel_size[0] * m.kernel_size[1] * m.kernel_size[2] * m.out_channels
                m.weight.data.normal_(0, math.sqrt(2. / n))
            elif isinstance(m, nn.ConvTranspose3d):
                n = m.kernel_size[0] * m.kernel_size[1] * m.kernel_size[2] * m.out_channels
                m.weight.data.normal_(0, math.sqrt(2. / n))
            elif isinstance(m, nn.BatchNorm2d):
                m.weight.data.fill_(1)
                m.bias.data.zero_()
            elif isinstance(m, SyncBatchNorm2d):
                m.weight.data.fill_(1)
                m.bias.data.zero_()
            elif isinstance(m, nn.BatchNorm3d):
                m.weight.data.fill_(1)
                m.bias.data.zero_()
            elif isinstance(m, nn.Linear):
                m.bias.data.zero_()

    def forward(self, input):
        left, right = torch.split(input_xy, 3, dim=1)

        refimg_fea = self.feature_extraction(left)
        targetimg_fea = self.feature_extraction(right)

        # matching
        cost = Variable(torch.FloatTensor(refimg_fea.size()[0], self.maxdisp // 4, refimg_fea.size()[2], refimg_fea.size()[3]).zero_()).cuda()

        for i in range(self.maxdisp // 4):
            if i > 0:
                cost[:, i, :, i:] = (refimg_fea[:, :, :, i:] * targetimg_fea[:, :, :, :-i]).mean(dim=1)
            else:
                cost[:, i, :, :] = (refimg_fea * targetimg_fea).mean(dim=1)

        cost = self.cost_aggs(cost)
        cost = torch.cat((cost, refimg_fea), 1)
        cost0 = self.dres0(cost)
        cost0 = self.dres1(cost0) + cost0

        out1 = self.dres2(cost0)
        out1 = out1 + cost0
        out1 = self.down2(torch.cat([out1, cost0], 1))

        out2 = self.dres3(out1)
        out2 = out2 + cost0
        out2 = self.down3(torch.cat([out2, out1, cost0], 1))

        out3 = self.dres4(out2)
        out3 = out3 + cost0

        # cost1 = self.classif1(out1)
        # cost2 = self.classif2(out2)  # + cost1
        cost3 = self.classif3(out3)  # + cost2
        # cost1 = torch.unsqueeze(cost1, 1)
        # cost2 = torch.unsqueeze(cost2, 1)
        cost3 = torch.unsqueeze(cost3, 1)

        # cost1 = F.upsample(cost1, [self.maxdisp, left.size()[2], left.size()[3]], mode='trilinear')
        # cost2 = F.upsample(cost2, [self.maxdisp, left.size()[2], left.size()[3]], mode='trilinear')

        # cost1 = torch.squeeze(cost1, 1)
        # pred1 = F.softmax(cost1, dim=1)
        # pred1 = disparityregression(self.maxdisp)(pred1)

        # cost2 = torch.squeeze(cost2, 1)
        # pred2 = F.softmax(cost2, dim=1)
        # pred2 = disparityregression(self.maxdisp)(pred2)

        cost3 = F.upsample(cost3, [self.maxdisp, left.size()[2], left.size()[3]], mode='trilinear')
        cost3 = torch.squeeze(cost3, 1)
        pred3 = F.softmax(cost3, dim=1)
        pred3 = disparityregression(self.maxdisp)(pred3)

        return {"predict": pred3}
