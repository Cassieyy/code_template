import torch
import torch.nn as nn
import torch.nn.functional as F
import numpy as np
import time
from torch.nn.init import kaiming_normal_
import logging
logger = logging.getLogger('global')


def conv(in_planes, out_planes, kernel_size=3, stride=1, use_bn=True):
    if use_bn:
        return nn.Sequential(nn.Conv2d(in_planes, out_planes, kernel_size=kernel_size, stride=stride,
                                       padding=(kernel_size - 1) // 2, bias=False),
                             nn.BatchNorm2d(out_planes),
                             nn.ReLU(inplace=True))
    else:
        return nn.Sequential(nn.Conv2d(in_planes, out_planes, kernel_size=kernel_size, stride=stride,
                                       padding=(kernel_size - 1) // 2, bias=False),
                             nn.ReLU(inplace=True))


class ResBlock(nn.Module):
    def __init__(self, n_in, n_out, stride=1):
        super(ResBlock, self).__init__()
        self.conv1 = nn.Conv2d(n_in, n_out, kernel_size=3, stride=stride, padding=1)
        self.bn1 = nn.BatchNorm2d(n_out)
        self.relu = nn.ReLU(inplace=True)
        self.conv2 = nn.Conv2d(n_out, n_out, kernel_size=3, padding=1)
        self.bn2 = nn.BatchNorm2d(n_out)

        if stride != 1 or n_out != n_in:
            self.shortcut = nn.Sequential(
                nn.Conv2d(n_in, n_out, kernel_size=1, stride=stride),
                nn.BatchNorm2d(n_out))
        else:
            self.shortcut = None

    def forward(self, x):
        residual = x
        if self.shortcut is not None:
            residual = self.shortcut(x)
        out = self.conv1(x)
        out = self.bn1(out)
        out = self.relu(out)
        out = self.conv2(out)
        out = self.bn2(out)

        out += residual
        out = self.relu(out)
        return out


class feature_extraction(nn.Module):
    def __init__(self, inplane=3, channels=[8,16,16,32,64,128]):
        super(feature_extraction, self).__init__()
        self.conv1 = conv(inplane, channels[0], 5, 2)
        self.conv2 = ResBlock(channels[0], channels[1], stride=2)
        self.conv3 = nn.Sequential(ResBlock(channels[1], channels[2], stride=2),
                                   ResBlock(channels[2], channels[2]))
        self.conv4 = nn.Sequential(ResBlock(channels[2], channels[3], stride=2),
                                   ResBlock(channels[3], channels[3]))
        self.conv5 = nn.Sequential(ResBlock(channels[3], channels[4], stride=2),
                                   ResBlock(channels[4], channels[4]))
        self.conv6 = nn.Sequential(ResBlock(channels[4], channels[5], stride=2),
                                   ResBlock(channels[5], channels[5]))

    def forward(self, x):
        layer1 = self.conv1(x)          # /2, 8
        layer2 = self.conv2(layer1)     # /4, 16
        layer3 = self.conv3(layer2)     # /8, 16
        layer4 = self.conv4(layer3)     # /16, 32
        layer5 = self.conv5(layer4)     # /32, 64
        layer6 = self.conv6(layer5)     # /64, 128

        return [layer6, layer5, layer4, layer3, layer2, layer1]


class Decoder(nn.Module):
    def __init__(self, inplane, outplane, nblocks=2, Block=ResBlock):
        super(Decoder, self).__init__()
        decoder = []
        for i in range(nblocks):
            decoder.append(Block(inplane, outplane))
            inplane = outplane
        self.decoder = nn.Sequential(*decoder)

        self.upsample = nn.Sequential(nn.ConvTranspose2d(outplane, outplane, kernel_size=4,
                                                         stride=2, padding=1, bias=False),
                                      nn.BatchNorm2d(outplane), nn.ReLU(inplace=True))

    def forward(self, x):
        cost = self.decoder(x)
        cost_up = self.upsample(cost)

        return cost_up


class DispNetC_s1_test1(nn.Module):
    def __init__(self, maxdisplist=[7, 3, 3, 3, 3, 3], input_channel=3, feature_channels=[8,16,16,32,64,128], **kwargs):
        super(DispNetC_s1_test1, self).__init__()
        self.input_channel = input_channel
        self.maxdisplist = maxdisplist

        self.levels = len(maxdisplist)
        self.cost_channel = [maxdisplist[0]] + [2 * i - 1 for i in maxdisplist[1:]]
        up_cost_channel = [0] + self.cost_channel

        self.feature_extraction = feature_extraction(input_channel, feature_channels)

        for idx in range(self.levels):
            setattr(self, 'cost_bn_relu_{}'.format(idx), nn.Sequential(nn.BatchNorm2d(self.cost_channel[idx]), nn.ReLU(inplace=True)))
            setattr(self, 'feat_redir_{}'.format(idx), conv(feature_channels[-1-idx], 8, 1))
            decoder_channel = self.cost_channel[idx] + 8 + up_cost_channel[idx] + (idx > 0)
            setattr(self, 'Decoder_{}'.format(idx), Decoder(decoder_channel, self.cost_channel[idx]))

        # weight initialization
        for m in self.modules():
            if isinstance(m, nn.Conv2d) or isinstance(m, nn.ConvTranspose2d):
                kaiming_normal_(m.weight.data)
                if m.bias is not None:
                    m.bias.data.zero_()
            elif isinstance(m, nn.BatchNorm2d):
                m.weight.data.fill_(1)
                m.bias.data.zero_()

    def warp(self, x, disp):
        """
        warp an image/tensor (im2) back to im1, according to the optical flow
        x: [B, C, H, W] (im2)
        flo: [B, 2, H, W] flow
        """
        B, C, H, W = x.size()
        # mesh grid
        xx = torch.arange(0, W, device='cuda').view(1, -1).repeat(H, 1)
        yy = torch.arange(0, H, device='cuda').view(-1, 1).repeat(1, W)
        xx = xx.view(1, 1, H, W).repeat(B, 1, 1, 1)
        yy = yy.view(1, 1, H, W).repeat(B, 1, 1, 1)
        vgrid = torch.cat((xx, yy), 1).float()

        # vgrid = Variable(grid)
        vgrid[:, :1, :, :] = vgrid[:, :1, :, :] - disp

        # scale grid to [-1,1]
        vgrid[:, 0, :, :] = 2.0 * vgrid[:, 0, :, :].clone() / max(W - 1, 1) - 1.0
        vgrid[:, 1, :, :] = 2.0 * vgrid[:, 1, :, :].clone() / max(H - 1, 1) - 1.0

        vgrid = vgrid.permute(0, 2, 3, 1)
        output = F.grid_sample(x, vgrid)
        return output

    def _build_volume_2d(self, feat_l, feat_r, maxdisp, stride=1):
        assert maxdisp % stride == 0  # Assume maxdisp is multiple of stride
        cost = torch.zeros((feat_l.size()[0], maxdisp // stride, feat_l.size()[2], feat_l.size()[3]), device='cuda')
        for i in range(0, maxdisp, stride):
            cost[:, i // stride, :, :i] = feat_l[:, :, :, :i].abs().sum(1)
            if i > 0:
                cost[:, i // stride, :, i:] = torch.norm(feat_l[:, :, :, i:] - feat_r[:, :, :, :-i], 1, 1)
            else:
                cost[:, i // stride, :, i:] = torch.norm(feat_l[:, :, :, :] - feat_r[:, :, :, :], 1, 1)

        return cost.contiguous()

    def _build_volume_2d3(self, feat_l, feat_r, maxdisp, disp, stride=1):
        size = feat_l.size()
        batch_disp = disp[:, None, :, :, :].repeat(1, maxdisp * 2 - 1, 1, 1, 1).view(-1, 1, size[-2], size[-1])
        batch_shift = torch.arange(-maxdisp + 1, maxdisp, device='cuda').repeat(size[0])[:, None, None, None] * stride
        batch_disp = batch_disp - batch_shift.float()
        batch_feat_l = feat_l[:, None, :, :, :].repeat(1, maxdisp * 2 - 1, 1, 1, 1).view(-1, size[-3], size[-2],
                                                                                         size[-1])
        batch_feat_r = feat_r[:, None, :, :, :].repeat(1, maxdisp * 2 - 1, 1, 1, 1).view(-1, size[-3], size[-2],
                                                                                         size[-1])
        cost = torch.norm(batch_feat_l - self.warp(batch_feat_r, batch_disp), 1, 1)
        cost = cost.view(size[0], -1, size[2], size[3])
        return cost.contiguous()

    def forward(self, input_xy):
        left, right = torch.split(input_xy, 3, dim=1)

        feats_l = self.feature_extraction(left)
        feats_r = self.feature_extraction(right)

        pred = []
        for idx in range(len(feats_l)):
            if idx == 0:
                cost = self._build_volume_2d(feats_l[idx], feats_r[idx], self.maxdisplist[idx])
                cost = getattr(self, 'cost_bn_relu_' + str(idx))(cost)
                feat_redir = getattr(self, 'feat_redir_' + str(idx))(feats_l[idx])
                decoder_input = torch.cat([cost, feat_redir], 1)
            else:
                cost = self._build_volume_2d3(feats_l[idx], feats_r[idx], self.maxdisplist[idx], disp_up)
                cost = getattr(self, 'cost_bn_relu_' + str(idx))(cost)
                feat_redir = getattr(self, 'feat_redir_' + str(idx))(feats_l[idx])
                decoder_input = torch.cat([cost, feat_redir, disp_up, cost_up], 1)

            cost_up = getattr(self, 'Decoder_' + str(idx))(decoder_input)

            if idx == 0:
                disp_up = disparityregression(0, self.maxdisplist[0], stride=32)(F.softmax(-cost_up, dim=1))
            else:
                disp_res = disparityregression(-self.maxdisplist[idx]+1, self.maxdisplist[idx], stride=32//(2**idx))(F.softmax(-cost_up, dim=1))
                disp_up = F.interpolate(disp_up, (disp_res.size(2), disp_res.size(3)), mode='bilinear', align_corners=True)
                disp_up = disp_up + disp_res

            pred.append(disp_up)

        if self.training:
            return {'preds': pred[::-1]}
        else:
            return pred[-1]


class disparityregression(nn.Module):
    def __init__(self, start, end, stride=1):
        super(disparityregression, self).__init__()
        self.disp = torch.arange(start * stride, end * stride, stride, device='cuda',
                                 requires_grad=False).view(1, -1, 1, 1).float()

    def forward(self, x):
        disp = self.disp.repeat(x.size()[0], 1, x.size()[2], x.size()[3])
        out = torch.sum(x * disp, 1, keepdim=True)
        return out
