import torch
import torch.nn as nn
import torch.utils.data
from torch.autograd import Variable
import torch.nn.functional as F
import math
import numpy as np
from networks.submodules import convbn_3d, disparityregression, conv_bn_relu
from networks.backbone import PSMNetBackbone
from networks.cost import build_cost
from networks.aggregator import Acf_Aggregator
from networks.disp_predict import soft_argmax as disp_predict


class ConfHead(nn.Module):
    """
    Args:
        in_planes (int): usually cost volume used to calculate confidence map with $in_planes$ in Channel Dimension
        batchNorm, (bool): whether use batch normalization layer, default True
    Inputs:
        cost, (tensor): cost volume in (BatchSize, in_planes, Height, Width) layout
    Outputs:
        confCost, (tensor): in (BatchSize, 1, Height, Width) layout
    """

    def __init__(self, in_planes=192, batch_norm=True):
        super(ConfHead, self).__init__()

        self.in_planes = in_planes
        self.sec_in_planes = int(self.in_planes // 3)
        self.sec_in_planes = self.sec_in_planes if self.sec_in_planes > 0 else 1

        self.conf_net = nn.Sequential(conv_bn_relu(batch_norm, self.in_planes, self.sec_in_planes, 3, 1, 1, bias=False),
                                      nn.Conv2d(self.sec_in_planes, 1, 1, 1, 0, bias=False))

    def forward(self, cost):
        conf = self.conf_net(cost)
        return conf


class AcfNet(nn.Module):
    def __init__(self, maxdisp=192, alpha=1, beta=1, **kwargs):
        super(AcfNet, self).__init__()
        self.maxdisp = maxdisp
        self.alpha = alpha
        self.beta = beta

        self.feature_extraction = PSMNetBackbone()
        self. aggreregator = Acf_Aggregator(max_disp=maxdisp)
        self.conf_heads = nn.ModuleList([ConfHead(maxdisp) for _ in range(3)])

        for m in self.modules():
            if isinstance(m, nn.Conv2d):
                n = m.kernel_size[0] * m.kernel_size[1] * m.out_channels
                m.weight.data.normal_(0, math.sqrt(2. / n))
            elif isinstance(m, nn.Conv3d):
                n = m.kernel_size[0] * m.kernel_size[1] * m.kernel_size[2] * m.out_channels
                m.weight.data.normal_(0, math.sqrt(2. / n))
            elif isinstance(m, nn.BatchNorm2d):
                m.weight.data.fill_(1)
                m.bias.data.zero_()
            elif isinstance(m, nn.BatchNorm3d):
                m.weight.data.fill_(1)
                m.bias.data.zero_()
            elif isinstance(m, nn.Linear):
                m.bias.data.zero_()

    def forward(self, input):
        left_feature, right_feature = self.feature_extraction(input)

        cost_volume = build_cost(left_feature, right_feature, int(self.maxdisp // 4))

        # cost3, cost2, cost1
        costs = self.aggreregator(cost_volume)

        # pred3, pred2, pred1
        preds = [disp_predict(cost) for cost in costs]
        
        # conf3, conf2, conf1
        confs = [conf_head(cost) for cost, conf_head in zip(costs, self.conf_heads)]
        
        # cost_var3, cost_var2, cost_var1
        cost_vars = [self.alpha * (1 - torch.sigmoid(conf)) + self.beta for conf in confs]

        if self.training:
            return {'preds': preds,
                    'confs': confs,
                    'costs': costs,
                    'cost_vars': cost_vars}
        else:
            return preds[0]
