import torch
import torch.nn as nn
import torch.nn.functional as F
import numpy as np
import time
from torch.autograd import Function
from torch.nn import init
from torch.nn.init import kaiming_normal_
from submodules import Corr, Py_Corr
from disp_prob_ops import prob2disp


class Deconv(nn.Module):
    def __init__(self, in_planes, out_planes, scale=2):
        super(Deconv, self).__init__()
        self.scale = scale
        self.conv_layer = conv(in_planes, out_planes, kernel_size=1)

    def forward(self, x):
        x = self.conv_layer(x)
        x = F.interpolate(x, scale_factor=2, mode='bilinear', align_corners=True)
        return x


def predict_flow(in_planes):
    return nn.Sequential(nn.Conv2d(in_planes, 1, kernel_size=3, stride=1, padding=1, bias=False),
                         nn.ReLU(inplace=True))


# def deconv():
#     return nn.Sequential(nn.ConvTranspose2d(in_planes, out_planes, kernel_size=4, stride=2, padding=1, bias=False),
#                          nn.ReLU(inplace=True))


def conv(in_planes, out_planes, kernel_size=3, stride=1, use_bn=True):
    if use_bn:
        return nn.Sequential(
            nn.Conv2d(in_planes, out_planes, kernel_size=kernel_size, stride=stride, padding=(kernel_size-1)//2, bias=False),
            nn.BatchNorm2d(out_planes),
            nn.ReLU(inplace=True)
        )
    else:
        return nn.Sequential(
            nn.Conv2d(in_planes, out_planes, kernel_size=kernel_size, stride=stride, padding=(kernel_size-1)//2, bias=False),
            nn.ReLU(inplace=True)
        )


class ResBlock(nn.Module):
    def __init__(self, n_in, n_out, stride=1):
        super(ResBlock, self).__init__()
        self.conv1 = nn.Conv2d(n_in, n_out, kernel_size=3, stride=stride, padding=1, bias=False)
        self.bn1 = nn.BatchNorm2d(n_out)
        self.relu = nn.ReLU(inplace=True)
        self.conv2 = nn.Conv2d(n_out, n_out, kernel_size=3, padding=1, bias=False)
        self.bn2 = nn.BatchNorm2d(n_out)

        if stride != 1 or n_out != n_in:
            self.shortcut = nn.Sequential(
                nn.Conv2d(n_in, n_out, kernel_size=1, stride=stride, bias=False),
                nn.BatchNorm2d(n_out))
        else:
            self.shortcut = None

    def forward(self, x):
        residual = x
        if self.shortcut is not None:
            residual = self.shortcut(x)
        out = self.conv1(x)
        out = self.bn1(out)
        out = self.relu(out)
        out = self.conv2(out)
        out = self.bn2(out)

        out += residual
        out = self.relu(out)
        return out


class DispNetC_s2(nn.Module):
    def __init__(self, maxdisp=192, softmax=False, input_channel=3, to_caffe=False, return_prob=False, **kwargs):
        super(DispNetC_s2, self).__init__()
        self.input_channel = input_channel
        self.maxdisp = maxdisp
        self.softmax = softmax
        self.return_prob = return_prob

        # shrink and extract features
        self.conv1 = conv(self.input_channel, 16, 7, 2)
        self.conv2 = ResBlock(16, 32, stride=2)
        self.conv3 = ResBlock(32, 32, stride=2)
        self.conv_redir = ResBlock(32, 16, stride=1)


        if to_caffe:
            self.corr = Corr(max_displacement=maxdisp // 8, pad=maxdisp // 8)
        else:
            self.corr = Py_Corr(max_displacement=maxdisp // 8, pad=maxdisp // 8)
        self.corr_activation = nn.ReLU(inplace=True)

        self.conv3_1 = ResBlock(maxdisp//8 + 1 + 16, 32)
        self.conv4 = ResBlock(32, 32, stride=2)
        self.conv4_1 = ResBlock(32, 32)
        self.conv5 = ResBlock(32, 64, stride=2)
        self.conv5_1 = ResBlock(64, 64)
        self.conv6 = ResBlock(64, 128, stride=2)
        self.conv6_1 = ResBlock(128, 128)

        self.pred_flow6 = predict_flow(128)

        # iconv with conv
        self.iconv5 = conv(129, 64)
        self.iconv4 = conv(65, 32)
        self.iconv3 = conv(65, 32)
        self.iconv2 = conv(49, 16)
        self.iconv1 = conv(33, 16)
        self.iconv0 = conv(17+self.input_channel, 16)

        # expand and produce disparity
        self.upconv5 = Deconv(128, 64)
        self.pred_flow5 = predict_flow(64)

        self.upconv4 = Deconv(64, 32)
        self.pred_flow4 = predict_flow(32)

        self.upconv3 = Deconv(32, 32)
        self.pred_flow3 = predict_flow(32)

        self.upconv2 = Deconv(32, 16)
        self.pred_flow2 = predict_flow(16)

        self.upconv1 = Deconv(16, 16)
        self.pred_flow1 = predict_flow(16)

        self.upconv0 = Deconv(16, 16)
        if self.softmax:
            self.disp_expand = ResBlock(16, self.maxdisp)
        else:
            self.pred_flow0 = predict_flow(16)

        # weight initialization
        for m in self.modules():
            if isinstance(m, nn.Conv2d) or isinstance(m, nn.ConvTranspose2d):
                kaiming_normal_(m.weight.data)
                if m.bias is not None:
                    m.bias.data.zero_()
            elif isinstance(m, nn.BatchNorm2d):
                m.weight.data.fill_(1)
                m.bias.data.zero_()

    def forward(self, input_xy):
        img_left, img_right = torch.split(input_xy, 3, dim=1)

        conv1_l = self.conv1(img_left)
        conv2_l = self.conv2(conv1_l)
        conv3a_l = self.conv3(conv2_l)

        conv1_r = self.conv1(img_right)
        conv2_r = self.conv2(conv1_r)
        conv3a_r = self.conv3(conv2_r)

        out_corr = self.corr(conv3a_l, conv3a_r)

        out_corr = self.corr_activation(out_corr)
        out_conv3a_redir = self.conv_redir(conv3a_l)
        in_conv3b = torch.cat((out_conv3a_redir, out_corr), 1)

        conv3b = self.conv3_1(in_conv3b)
        conv4a = self.conv4(conv3b)
        conv4b = self.conv4_1(conv4a)
        conv5a = self.conv5(conv4b)
        conv5b = self.conv5_1(conv5a)
        conv6a = self.conv6(conv5b)
        conv6b = self.conv6_1(conv6a)

        pr6 = self.pred_flow6(conv6b)
        upconv5 = self.upconv5(conv6b)
        upflow6 = F.interpolate(pr6, scale_factor=2, mode='bilinear', align_corners=True)
        concat5 = torch.cat((upconv5, upflow6, conv5b), 1)
        iconv5 = self.iconv5(concat5)

        pr5 = self.pred_flow5(iconv5)
        upconv4 = self.upconv4(iconv5)
        upflow5 = F.interpolate(pr5, scale_factor=2, mode='bilinear', align_corners=True)
        concat4 = torch.cat((upconv4, upflow5, conv4b), 1)
        iconv4 = self.iconv4(concat4)
        
        pr4 = self.pred_flow4(iconv4)
        upconv3 = self.upconv3(iconv4)
        upflow4 = F.interpolate(pr4, scale_factor=2, mode='bilinear', align_corners=True)
        concat3 = torch.cat((upconv3, upflow4, conv3b), 1)
        iconv3 = self.iconv3(concat3)

        pr3 = self.pred_flow3(iconv3)
        upconv2 = self.upconv2(iconv3)
        upflow3 = F.interpolate(pr3, scale_factor=2, mode='bilinear', align_corners=True)
        concat2 = torch.cat((upconv2, upflow3, conv2_l), 1)
        iconv2 = self.iconv2(concat2)

        pr2 = self.pred_flow2(iconv2)
        upconv1 = self.upconv1(iconv2)
        upflow2 = F.interpolate(pr2, scale_factor=2, mode='bilinear', align_corners=True)
        concat1 = torch.cat((upconv1, upflow2, conv1_l), 1)
        iconv1 = self.iconv1(concat1)

        pr1 = self.pred_flow1(iconv1)
        upconv0 = self.upconv0(iconv1)
        upflow1 = F.interpolate(pr1, scale_factor=2, mode='bilinear', align_corners=True)
        concat0 = torch.cat((upconv0, upflow1, img_left), 1)
        iconv0 = self.iconv0(concat0)

        if self.softmax:
            pr0 = self.disp_expand(iconv0)

            if not self.return_prob:
                prob = F.softmax(pr0, dim=1)
                pr0 = disparity_regression(prob, self.maxdisp)
        else:
            pr0 = self.pred_flow0(iconv0)

        if self.training:
            return {'preds': [pr0, pr1, pr2, pr3, pr4, pr5, pr6],
                    'left_img': img_left}
        else:
            if self.softmax:
                if self.return_prob:
                    disp, prob = prob2disp(pr0, normalize=True, mindisp=0, return_prob=True)
                    return {'preds': disp,
                            'probs': prob}
                else:
                    return {'preds': pr0,
                            'probs': prob}
            else:
                return {'preds': pr0}

    def weight_parameters(self):
        return [param for name, param in self.named_parameters() if 'weight' in name]

    def bias_parameters(self):
        return [param for name, param in self.named_parameters() if 'bias' in name]


def disparity_regression(x, maxdisp):
    disp_values = torch.arange(0, maxdisp, dtype=x.dtype, device=x.device)
    disp_values = disp_values.view(1, maxdisp, 1, 1)
    return torch.sum(x * disp_values, 1, keepdim=True)

if __name__=='__main__':
  net = DispNetC_s2()
  print(net)
