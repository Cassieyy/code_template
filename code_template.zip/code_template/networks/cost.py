import torch
import torch.nn.functional as F


def build_cost(left_feature, right_feature, max_disp, start_disp=0, dilation=1):
    end_disp = start_disp + max_disp - 1
    disp_sample_number = (max_disp + dilation - 1) // dilation

    device = left_feature.device
    N, C, H, W = left_feature.shape
    concat_fm = torch.zeros(N, C * 2, disp_sample_number, H, W).to(device)

    idx = 0
    for i in range(start_disp, end_disp + 1, dilation):
        if i > 0:
            concat_fm[:, :C, idx, :, i:] = left_feature[:, :, :, i:]
            concat_fm[:, C:, idx, :, i:] = right_feature[:, :, :, :-i]
        elif i == 0:
            concat_fm[:, :C, idx, :, :] = left_feature
            concat_fm[:, C:, idx, :, :] = right_feature
        else:
            concat_fm[:, :C, idx, :, :i] = left_feature[:, :, :, :i]
            concat_fm[:, C:, idx, :, :i] = right_feature[:, :, :, abs(i):]
        idx = idx + 1

    concat_fm = concat_fm.contiguous()
    return concat_fm


# used for to_caffe
class Corr(torch.nn.Module):
    def __init__(self, max_displacement=40, pad=40, single_direction=-1, kernel_size=1):
        super(Corr, self).__init__()
        self.max_displacement = int(max_displacement)
        self.pad = int(pad)
        self.single_direction = int(single_direction)
        self.kernel_size = int(kernel_size)

    def forward(self, img_left, img_right):
        return Correlation1D.apply(img_left, img_right, self.max_displacement, self.pad, self.single_direction,
                                   self.kernel_size)


# output same as Correlation1D(max_displacement=max_disp, pad=max_disp, single_direction=-1, kernel_size=1)
class Py_Corr(torch.nn.Module):
    def __init__(self, max_displacement=40, pad=40, single_direction=-1, kernel_size=1):
        super(Py_Corr, self).__init__()
        self.max_displacement = int(max_displacement)
        self.pad = int(pad)
        self.single_direction = int(single_direction)
        self.kernel_size = int(kernel_size)

    def forward(self, img_left, img_right):
        B, C, H, W = img_left.shape
        volume = img_left.new_zeros([B, self.max_displacement+1, H, W])
        for i in range(1, self.max_displacement+2):
            volume[:, self.max_displacement+1-i, :, i:] = (img_left[:, :, :, i:] * img_right[:, :, :, :-i]).mean(dim=1)
        volume = volume.contiguous()
        return volume


class Py_SAD(torch.nn.Module):
    def __init__(self, max_displacement=40, pad=40, single_direction=-1, kernel_size=1):
        super(Py_SAD, self).__init__()
        self.max_displacement = int(max_displacement)
        self.pad = int(pad)
        self.single_direction = int(single_direction)
        self.kernel_size = int(kernel_size)

    def forward(self, img_left, img_right):
        B, C, H, W = img_left.shape
        volume = img_left.new_zeros([B, self.max_displacement+1, H, W])
        for i in range(1, self.max_displacement+2):
            volume[:, self.max_displacement+1-i, :, i:] = torch.mean(torch.abs(img_left[:, :, :, i:] - img_right[:, :, :, :-i]), 1)
        volume = volume.contiguous()
        return volume


class Py_Corr_SAD(torch.nn.Module):
    def __init__(self, max_displacement=40, pad=40, single_direction=-1, kernel_size=1):
        super(Py_Corr_SAD, self).__init__()
        self.max_displacement = int(max_displacement)
        self.pad = int(pad)
        self.single_direction = int(single_direction)
        self.kernel_size = int(kernel_size)

    def forward(self, img_left, img_right):
        B, C, H, W = img_left.shape
        volume = img_left.new_zeros([B, 2 * (self.max_displacement + 1), H, W])
        for i in range(1, self.max_displacement+2):
            volume[:, self.max_displacement + 1 - i, :, i:] = (img_left[:, :, :, i:] * img_right[:, :, :, :-i]).mean(dim=1)
            volume[:, 2 * (self.max_displacement + 1) - i, :, i:] = torch.mean(torch.abs(img_left[:, :, :, i:] - img_right[:, :, :, :-i]), 1)
        volume = volume.contiguous()
        return volume


class Corr_zero(torch.nn.Module):
    def __init__(self, max_displacement=40, pad=40, single_direction=-1, kernel_size=1):
        super(Corr_zero, self).__init__()
        self.max_displacement = int(max_displacement)
        self.pad = int(pad)
        self.single_direction = int(single_direction)
        self.kernel_size = int(kernel_size)

    def forward(self, img_left, img_right):
        B, C, H, W = img_left.shape
        volume = img_left.new_zeros([B, self.max_displacement+1, H, W])
        for i in range(self.max_displacement+1):
            volume[:, self.max_displacement-i, :, i:] = (img_left[:, :, :, i:] * img_right[:, :, :, :-i]).mean(dim=1)
        volume = volume.contiguous()
        return volume