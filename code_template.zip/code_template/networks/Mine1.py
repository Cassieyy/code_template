import torch
import torch.nn as nn
import torch.nn.functional as F
import numpy as np
import time
from torch.autograd import Function
from torch.nn import init
from torch.nn.init import kaiming_normal_
from networks.submodules import predict_flow, Corr, Py_Corr, deconv, Py_Corr_Attention, disparity_regression, Py_Cat_Attention

from linklink.nn import SyncBatchNorm2d
from linklink.nn import syncbnVarMode_t

BN = None


def conv(in_planes, out_planes, kernel_size=3, stride=1, dilation=1, use_bn=True):
    if use_bn:
        return nn.Sequential(
            nn.Conv2d(in_planes, out_planes, kernel_size=kernel_size, stride=stride, padding=dilation if dilation > 1 else (kernel_size - 1) // 2, dilation=dilation, bias=True),
            BN(out_planes),
            nn.LeakyReLU(0.1, inplace=False))
    else:
        return nn.Sequential(
            nn.Conv2d(in_planes, out_planes, kernel_size=kernel_size, stride=stride, padding=dilation if dilation > 1 else (kernel_size - 1) // 2, dilation=dilation, bias=True),
            nn.LeakyReLU(0.1, inplace=False))


def deconv(in_planes, out_planes):
    return nn.Sequential(nn.ConvTranspose2d(in_planes, out_planes, kernel_size=4, stride=2, padding=1, bias=True),
                         BN(out_planes),
                         nn.LeakyReLU(0.1, inplace=False))


class hourglass(nn.Module):
    def __init__(self, in_channels):
        super(hourglass, self).__init__()

        self.conv1 = conv(in_channels, in_channels * 2, 3, 2)

        self.conv2 = conv(in_channels * 2, in_channels * 2, 3, 1)

        self.conv3 = conv(in_channels * 2, in_channels * 4, 3, 2)

        self.conv4 = conv(in_channels * 4, in_channels * 4, 3, 1)

        self.conv5 = deconv(in_channels * 4, in_channels * 2)

        self.conv6 = deconv(in_channels * 2, in_channels)

        self.redir1 = conv(in_channels, in_channels, 1)
        self.redir2 = conv(in_channels * 2, in_channels * 2, 1)

    def forward(self, x):
        conv1 = self.conv1(x)
        conv2 = self.conv2(conv1)

        conv3 = self.conv3(conv2)
        conv4 = self.conv4(conv3)

        conv5 = F.relu(self.conv5(conv4) + self.redir2(conv2), inplace=False)
        conv6 = F.relu(self.conv6(conv5) + self.redir1(x), inplace=False)

        return conv6


class BasicBlock(nn.Module):
    expansion = 1

    def __init__(self, inplanes, planes, stride, downsample, dilation):
        super(BasicBlock, self).__init__()
        self.conv1 = conv(inplanes, planes, 3, stride, dilation)
        self.conv2 = conv(planes, planes, 3, 1, dilation)
        self.downsample = downsample
        self.stride = stride

    def forward(self, x):
        out = self.conv1(x)
        out = self.conv2(out)

        if self.downsample is not None:
            x = self.downsample(x)
        out += x
        return out


class feature_extraction(nn.Module):
    def __init__(self):
        super(feature_extraction, self).__init__()
        self.inplanes = 32
        self.firstconv = nn.Sequential(conv(3, 32, 3, 2, 1),
                                       conv(32, 32, 3, 1, 1),
                                       conv(32, 32, 3, 1, 1))

        self.layer1 = self._make_layer(BasicBlock, 32, 3, 1, 1)
        self.layer2 = self._make_layer(BasicBlock, 64, 16, 2, 1)
        self.layer3 = self._make_layer(BasicBlock, 128, 3, 1, 1)
        self.layer4 = self._make_layer(BasicBlock, 128, 3, 1, 2)

    def _make_layer(self, block, planes, blocks, stride, dilation):
        downsample = None
        if stride != 1 or self.inplanes != planes * block.expansion:
            downsample = nn.Sequential(nn.Conv2d(self.inplanes, planes * block.expansion, kernel_size=1, stride=stride, bias=True),
                                       BN(planes * block.expansion))
        layers = []
        layers.append(block(self.inplanes, planes, stride, downsample, dilation))
        self.inplanes = planes * block.expansion
        for i in range(1, blocks):
            layers.append(block(self.inplanes, planes, 1, None, dilation))
        return nn.Sequential(*layers)

    def forward(self, x):
        x = self.firstconv(x)
        x = self.layer1(x)
        l2 = self.layer2(x)
        l3 = self.layer3(l2)
        l4 = self.layer4(l3)

        return torch.cat((l2, l3, l4), dim=1)


class Mine1(nn.Module):
    def __init__(self, maxdisp=-1, bn_group=None, use_sync_bn=True, **kwargs):
        global BN

        def BNFunc(*args, **kwargs):
            return SyncBatchNorm2d(*args, **kwargs, group=bn_group,
                                   sync_stats=True, var_mode=syncbnVarMode_t.L2)
        if use_sync_bn:
            BN = BNFunc
        else:
            BN = nn.BatchNorm2d
        super(Mine1, self).__init__()
        self.maxdisp = maxdisp

        self.feature_extraction = feature_extraction()    # stride 4
        # self.corr = Py_Corr(max_displacement=maxdisp // 4, pad=maxdisp // 8)
        self.corr = Py_Cat_Attention(max_displacement=maxdisp // 4, pad=maxdisp // 4, inplanes=640)

        self.dres0 = nn.Sequential(conv(maxdisp // 4 + 1, 32),
                                   conv(32, 32))

        self.dres1 = nn.Sequential(conv(32, 32),
                                   conv(32, 32))

        self.dres2 = hourglass(32)

        self.dres3 = hourglass(32)

        self.dres4 = hourglass(32)

        self.classif0 = nn.Sequential(conv(32, 32),
                                      nn.Conv2d(32, maxdisp, 3))

        self.classif1 = nn.Sequential(conv(32, 32),
                                      nn.Conv2d(32, maxdisp, 3))

        self.classif2 = nn.Sequential(conv(32, 32),
                                      nn.Conv2d(32, maxdisp, 3))

        self.classif3 = nn.Sequential(conv(32, 32),
                                      nn.Conv2d(32, maxdisp, 3))

        # weight initialization
        for m in self.modules():
            if isinstance(m, nn.Conv2d) or isinstance(m, nn.ConvTranspose2d):
                kaiming_normal_(m.weight.data)
                if m.bias is not None:
                    m.bias.data.zero_()
            elif isinstance(m, nn.BatchNorm2d):
                m.weight.data.fill_(1)
                m.bias.data.zero_()

    def forward(self, input_xy):
        img_left, img_right = torch.split(input_xy, 3, dim=1)
        B, C, H, W = img_left.size()
        features_left = self.feature_extraction(img_left)
        features_right = self.feature_extraction(img_right)
        volume = self.corr(features_left, features_right)

        cost0 = self.dres0(volume)
        cost0 = self.dres1(cost0) + cost0
        out1 = self.dres2(cost0)
        out2 = self.dres3(out1)
        out3 = self.dres4(out2)

        if self.training:
            cost0 = self.classif0(cost0)
            cost1 = self.classif1(out1)
            cost2 = self.classif2(out2)
            cost3 = self.classif3(out3)

            cost0 = F.interpolate(cost0, [H, W], mode='bilinear', align_corners=True)
            pred0 = F.softmax(cost0, dim=1)
            pred0 = disparity_regression(pred0, self.maxdisp)

            cost1 = F.interpolate(cost1, [H, W], mode='bilinear', align_corners=True)
            pred1 = F.softmax(cost1, dim=1)
            pred1 = disparity_regression(pred1, self.maxdisp)

            cost2 = F.interpolate(cost2, [H, W], mode='bilinear', align_corners=True)
            pred2 = F.softmax(cost2, dim=1)
            pred2 = disparity_regression(pred2, self.maxdisp)

            cost3 = F.interpolate(cost3, [H, W], mode='bilinear', align_corners=True)
            pred3 = F.softmax(cost3, dim=1)
            pred3 = disparity_regression(pred3, self.maxdisp)
            return pred3, pred2, pred1, pred0
        else:
            cost3 = self.classif3(out3)
            cost3 = F.interpolate(cost3, [H, W], mode='bilinear', align_corners=True)
            pred3 = F.softmax(cost3, dim=1)
            pred3 = disparity_regression(pred3, self.maxdisp)
            return pred3

    def weight_parameters(self):
        return [param for name, param in self.named_parameters() if 'weight' in name]

    def bias_parameters(self):
        return [param for name, param in self.named_parameters() if 'bias' in name]


