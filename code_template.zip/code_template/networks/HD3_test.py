import torch
import torch.nn as nn
import torch.nn.functional as F
from networks.dla_up import DLAEncoder as dlaup_encoder
from networks.decoder import HDADecoder
from networks.disp_prob_ops import prob2disp
import logging
logger = logging.getLogger('global')


class Decoder(nn.Module):
    def __init__(self, inplane, block, classes, up_classes):
        super(Decoder, self).__init__()
        self.mapping = block(inplane, 32)
        self.cls = nn.Sequential(nn.BatchNorm2d(32), nn.ReLU(inplace=True),
                                 nn.Conv2d(32, classes, kernel_size=1, stride=1, padding=0, bias=True))
        self.up = None
        if up_classes > 0:
            self.up = nn.Sequential(nn.BatchNorm2d(32),
                                    nn.ReLU(inplace=True),
                                    nn.ConvTranspose2d(32, up_classes,kernel_size=4,
                                                       stride=2,padding=1,bias=False), 
                                    nn.BatchNorm2d(up_classes), 
                                    nn.ReLU(inplace=True))

    def forward(self, x):
        out = self.mapping(x)
        prob = self.cls(out)
        up_feat = self.up(out) if self.up else None
        return prob, up_feat


class HD3Net_test(nn.Module):
    def __init__(self, encoder='dlaup', decoder='hda', corr_range=[12, 3, 3, 3, 3], first_level=2, **kwargs):
        super(HD3Net_test, self).__init__()
        self.corr_range = corr_range
        self.first_level = first_level
        self.levels = len(corr_range)
        self.classes = [corr_range[0] + 1] + [2 * d + 1 for d in corr_range[1:]]

        if encoder == 'dlaup':
            pyr_channels = [16, 16, 32, 32, 32, 32, 64]
            self.encoder = dlaup_encoder(pyr_channels, first_level=0)
        else:
            raise ValueError('Unknown encoder {}'.format(encoder))

        if decoder == 'hda':
            dec_block = HDADecoder
        else:
            raise ValueError('Unknown decoder {}'.format(decoder))

        feat_d_offset = pyr_channels[::-1][first_level:]
        up_d_offset = [0] + self.classes[1:]

        for l in range(self.levels):
            setattr(self, 'cost_bn_{}'.format(l), nn.BatchNorm2d(self.classes[l]))
            input_d = self.classes[l] + feat_d_offset[l] + up_d_offset[l] + (l > 0)
            if l < self.levels - 1:
                up_classes = self.classes[l + 1]
            else:
                up_classes = -1
            setattr(self, 'Decoder_{}'.format(l), Decoder(input_d, dec_block, self.classes[l], up_classes=up_classes))

        for m in self.modules():
            classname = m.__class__.__name__
            if isinstance(m, (nn.Conv2d, nn.ConvTranspose2d)):
                m.weight.data.normal_(0, 0.02)
                if m.bias is not None:
                    m.bias.data.zero_()
            elif classname.find('nn.BatchNorm2d') != -1:
                m.weight.data.fill_(1)
                m.bias.data.zero_()
                
    def warp(self, x, disp, mul=True):
        """
        warp an image/tensor (im2) back to im1, according to the optical flow
        x: [B, C, H, W] (im2)
        flo: [B, 2, H, W] flow
        """
        B, C, H, W = x.size()
        # mesh grid
        xx = torch.arange(0, W, device='cuda').view(1, -1).repeat(H, 1)
        yy = torch.arange(0, H, device='cuda').view(-1, 1).repeat(1, W)
        xx = xx.view(1, 1, H, W).repeat(B, 1, 1, 1)
        yy = yy.view(1, 1, H, W).repeat(B, 1, 1, 1)
        vgrid = torch.cat((xx, yy), 1).float()

        # vgrid = Variable(grid)
        vgrid[:, :1, :, :] = vgrid[:, :1, :, :] - disp

        # scale grid to [-1,1]
        vgrid[:, 0, :, :] = 2.0 * vgrid[:, 0, :, :].clone() / max(W - 1, 1) - 1.0
        vgrid[:, 1, :, :] = 2.0 * vgrid[:, 1, :, :].clone() / max(H - 1, 1) - 1.0

        vgrid = vgrid.permute(0, 2, 3, 1)
        output = F.grid_sample(x, vgrid, padding_mode='border')

        mask = torch.ones(x.size(), device='cuda')
        mask = F.grid_sample(mask, vgrid, padding_mode='zeros')

        mask[mask < 0.9999] = 0
        mask[mask > 0] = 1

        if mul:
            return output * mask
        else:
            return output

    # def build_cost_abs(self, feat_l, feat_r, maxdisp, stride=1):
    #     cost = torch.zeros((feat_l.size()[0], maxdisp // stride, feat_l.size()[2], feat_l.size()[3]), device='cuda')
    #     for i in range(0, maxdisp, stride):
    #         cost[:, i // stride, :, :i] = feat_l[:, :, :, :i].abs().sum(1)
    #         if i > 0:
    #             cost[:, i // stride, :, i:] = torch.norm(feat_l[:, :, :, i:] - feat_r[:, :, :, :-i], 1, 1)
    #         else:
    #             cost[:, i // stride, :, i:] = torch.norm(feat_l[:, :, :, :] - feat_r[:, :, :, :], 1, 1)
    # 
    #     return cost.contiguous()

    def build_cost_corr(self, feat_l, feat_r, maxdisp, single_direction=1):
        if single_direction == 1:
            low_disp = 0
            high_disp = maxdisp + 1
        elif single_direction == -1:
            low_disp = - maxdisp
            high_disp = 1
        elif single_direction == 0:
            low_disp = - maxdisp
            high_disp = maxdisp+1

        cost = torch.zeros((feat_l.size()[0], high_disp-low_disp, feat_l.size()[2], feat_l.size()[3]), device='cuda')
        for i in range(low_disp, high_disp):
            idx = i - low_disp
            if i > 0:
                cost[:, idx, :, i:] = (feat_l[:, :, :, i:] * feat_r[:, :, :, :-i]).mean(dim=1)
            elif i < 0:
                cost[:, idx, :, :i] = (feat_l[:, :, :, :i] * feat_r[:, :, :, -i:]).mean(dim=1)
            else:
                cost[:, idx, :, :] = (feat_l * feat_r).mean(dim=1)

        return cost.contiguous()

    def forward(self, input_xy):
        left, right = torch.split(input_xy, 3, dim=1)
        feat_list_l = self.encoder(left)[self.first_level:]
        feat_list_r = self.encoder(right)[self.first_level:]

        ms_prob = []
        ms_pred = []
        for l in range(self.levels):
            feat_left = feat_list_l[l]
            feat_right = feat_list_r[l]

            if l == 0:
                cost_volume = self.build_cost_corr(feat_left, feat_right, self.corr_range[l], single_direction=1)
            else:
                feat_right = self.warp(feat_right, up_disp)
                cost_volume = self.build_cost_corr(feat_left, feat_right, self.corr_range[l], single_direction=0)

            cost_bn = getattr(self, 'cost_bn_' + str(l))
            cost_volume = cost_bn(cost_volume)

            if l == 0:
                decoder_input = torch.cat([cost_volume, feat_left], 1)
            else:
                decoder_input = torch.cat([cost_volume, feat_left, up_feat, up_disp], 1)

            decoder = getattr(self, 'Decoder_' + str(l))
            prob_map, up_feat = decoder(decoder_input)

            if l == 0:
                curr_disp = prob2disp(prob_map, True, mindisp=0)
            else:
                curr_disp = prob2disp(prob_map, True, mindisp=-self.corr_range[l])

            if l > 0:
                curr_disp += up_disp

            curr_disp = torch.clamp(curr_disp, min=0)
            ms_pred.append(curr_disp)
            ms_prob.append(prob_map)

            if l < self.levels - 1:
                scale = 2
                up_disp = scale * F.interpolate(curr_disp, scale_factor=scale, mode='bilinear', align_corners=True)

        if self.training:
            return {'ms_prob': ms_prob,
                    'preds': ms_pred}
        else:
            return {'preds': ms_pred[-1]}
