from networks.DispNetC import DispNetC
from networks.DispNetC_s1 import DispNetC_s1
from networks.PSMNet import PSMNet
from networks.GwcNet import GwcNet
from networks.AcfNet import AcfNet
from networks.AnyNet import AnyNet
from networks.DispNetC_s2 import DispNetC_s2

from networks.AnyNet_test import AnyNet_test
from networks.DispNetC_test import DispNetC_test
from networks.DispNetC_s1_test import DispNetC_s1_test
from networks.DispNetC_s1_test1 import DispNetC_s1_test1
from networks.HD3_test import HD3Net_test
from networks.HD3_test1 import HD3Net_test1
from networks.HD3 import HD3Net



from utils.common import logger
import logging
logger = logging.getLogger('global')

SUPPORT_NETS = {'dispnetc': DispNetC,
                'dispnetc_s1': DispNetC_s1,
                'dispnetc_s2': DispNetC_s2,
                'gwcnet': GwcNet,
                'psmnet': PSMNet,
                'acfnet': AcfNet,
                'dispnetc_test': DispNetC_test,
                'anynet': AnyNet,
                'anynet_test': AnyNet_test,
                'dispnetc_s1_test':DispNetC_s1_test,
                'dispnetc_s1_test1':DispNetC_s1_test1,
                'hd3_test': HD3Net_test,
                'hd3_test1': HD3Net_test1,
                'hd3': HD3Net}


def build_net(net_name):
    net = SUPPORT_NETS.get(net_name, None)
    if net is None:
        logger.error('Current supporting nets: %s , Unsupport net: %s', SUPPORT_NETS.keys(), net_name)
        raise 'Unsupport net: %s' % net_name
    return net
