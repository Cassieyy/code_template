import os
import time
import shutil
import torch
import torch.nn.functional as F
import numpy as np
from torch.utils.data import DataLoader

from net_builder import build_net
from dataloader.Listloader import FileLoader
import logging
from losses.multiscaleloss import EPE, MultiScaleLoss, D1_error
from losses.Acf_loss import AcfLoss
# from losses.ga_loss import GaLoss
from losses.hd3_losses import HD3_loss
from losses.hd3_ori_losses import HD3_ori_loss
from losses.metrics import disp_evaluation
from losses.common_loss import Smooth_L1_Loss
from losses.prob_losses import Prob_loss
from tensorboardX import SummaryWriter
import cv2
import skimage.io
from PIL import Image
from torch.nn.parallel import DistributedDataParallel as DDP
from torch.utils.data.distributed import DistributedSampler
from utils.distributed_utils import reduce_gradients, DistModule
from utils.scheduler import get_scheduler
from torch.optim.lr_scheduler import StepLR
from utils.log_helper import MetricLogger
import linklink as link

logger = logging.getLogger('global')


class XXTrainer(object):
    def __init__(self, opt):
        super(XXTrainer, self).__init__()
        self.opt = opt
        self.initialize()

    def _prepare_dataset(self):
        if not self.opt.evaluate:
            train_dataset = CustomDateset()
            self.n_train_img = len(train_dataset)
            self.max_iter = self.n_train_img * self.opt.train_epoch // self.opt.batch_size // self.opt.world_size
            train_sampler = DistributedSampler(train_dataset)
            self.train_loader = DataLoader(train_dataset, shuffle=False, num_workers=4, batch_size=self.opt.batch_size,
                                           pin_memory=True, sampler=train_sampler)
            logger.info('train with {} pair images'.format(self.n_train_img))

            self.val_loader = []
            self.opt.val_dir = self.opt.get('val_dir', '')
            if self.opt.val_dir != '':
                val_dataset = CustomDateset()
                self.n_val_img = len(val_dataset)
                val_sampler = DistributedSampler(val_dataset)
                self.val_loader = DataLoader(val_dataset, shuffle=False, num_workers=0, batch_size=1,
                                             pin_memory=True, sampler=val_sampler)
                logger.info('val with {} pair images'.format(self.n_val_img))

        test_width = self.opt.get('test_width', None)
        test_height = self.opt.get('test_height', None)
        test_dataset = CustomDateset()
        self.n_test_img = len(test_dataset)
        test_sampler = DistributedSampler(test_dataset)
        self.test_loader = DataLoader(test_dataset, shuffle=False, num_workers=0, batch_size=1,
                                      pin_memory=True, sampler=test_sampler)
        logger.info('test with {} pair images'.format(self.n_test_img))
        logger.info('Build dataset done.')

    def _build_net(self):
        self.net = build_net(self.opt.net_name)(**self.opt.model)

        if not self.opt.evaluate:
            if self.opt.bn == 'sync':
                try:
                    import apex
                    self.net = apex.parallel.convert_syncbn_model(self.net)
                except:
                    logger.info('not install apex. thus no sync bn')
            elif self.opt.bn == 'freeze':
                self.net = self.net.apply(freeze_bn)

        if self.opt.evaluate:
            self.load_state_keywise(self.opt.resume_model)
            logger.info('Load resume model from {}'.format(self.opt.resume_model))
        elif self.opt.pretrain_model == '':
            logger.info('Initial a new model...')
        else:
            if os.path.isfile(self.opt.pretrain_model):
                self.load_state_keywise(self.opt.pretrain_model)
                logger.info('Load pretrain model from {}'.format(self.opt.pretrain_model))
            else:
                logger.error('Can not find the specific model %s, initial a new model...', self.opt.pretrain_model)


        if not self.opt.tocaffe or not self.opt.toonnx:
            self.net = DDP(self.net,device_ids=[rank])
        logger.info('Build model done.')

    def _build_optimizer(self):
        if self.opt.optimizer.type == 'SGD':
            self.optimizer = torch.optim.SGD(self.net.parameters(), self.opt.lr_scheduler.base_lr,
                                             momentum=0.9, weight_decay=0.0005)
        elif self.opt.optimizer.type == 'RMSprop':
            self.optimizer = torch.optim.RMSprop(self.net.parameters(), self.opt.lr_scheduler.base_lr)
        else:
            self.optimizer = torch.optim.Adam(self.net.parameters(), self.opt.lr_scheduler.base_lr, amsgrad=True)

        # learning rate
        # self.opt.lr_scheduler.max_iter = self.max_iter
        # self.opt.lr_scheduler['optimizer'] = self.optimizer
        # self.opt.lr_scheduler['last_iter'] = self.opt.last_iter
        # self.opt.lr_scheduler['lr_steps'] = [int(self.max_iter * i) for i in self.opt.lr_scheduler['lr_steps']]
        # self.opt.lr_scheduler['warmup_steps'] = int(self.opt.lr_scheduler['warmup_steps'] * self.max_iter)
        # self.lr_scheduler = get_scheduler(self.opt.lr_scheduler)
        if self.opt.lr_scheduler.type == 'STEP':
            self.lr_scheduler = StepLR(self.optimizer,self.opt.lr_scheduler.step_size,self.opt.lr_scheduler.gamma,self.opt.lr_scheduler.verbose)


        # loss
        if self.opt.loss.type == 'multi_scale':
            self.loss_function = MultiScaleLoss(**self.opt.loss.kwargs)
        elif self.opt.loss.type == 'acf_loss':
            self.loss_function = AcfLoss(**self.opt.loss.kwargs)
        elif self.opt.loss.type == 'hd3_loss':
            self.loss_function = HD3_loss(**self.opt.loss.kwargs)
        elif self.opt.loss.type == 'smooth_l1':
            self.loss_function = Smooth_L1_Loss(**self.opt.loss.kwargs)
        elif self.opt.loss.type == 'hd3_ori_loss':
            self.loss_function = HD3_ori_loss(**self.opt.loss.kwargs)
        elif self.opt.loss.type == 'prob_loss':
            self.loss_function = Prob_loss(**self.opt.loss.kwargs)
        else:
            logger.error('incorrect loss type {}'.format(self.opt.loss.type))

    def initialize(self):
        self._build_net()
        if not self.opt.tocaffe or not self.opt.toonnx:
            self._prepare_dataset()
            if not self.opt.evaluate:
                self._build_optimizer()

    def val(self):
        self.net.eval()
        val_epe = []
        val_d1 = []

        with torch.no_grad():
            for i, sample_batched in enumerate(self.val_loader):
                input_var = torch.cat((sample_batched['left_img'], sample_batched['right_img']), 1).cuda()
                target_var = sample_batched['left_disp'].cuda()

                output = self.net(input_var)
                val_iter_epe = EPE(output, target_var) / self.opt.world_size
                val_iter_d1 = D1_error(output, target_var) / self.opt.world_size
                link.allreduce(val_iter_epe)
                link.allreduce(val_iter_d1)
                val_epe.append(val_iter_epe.item())
                val_d1.append(val_iter_d1.item() * 100)
        return np.mean(val_epe), np.mean(val_d1)

    def train(self):
        self.net.train()
        writer = SummaryWriter(self.opt.train_output_directory) if self.opt.rank == 0 else None
        val_interval = self.opt.get('val_interval', 200)
        last_epoch = 1
        best_val_d1 = 1000
        best_val_epe = 1000
        best_epoch = -1
        running_loss = MetricLogger(self.opt.print_freq)
        train_start_time = time.time()

        for iter_train, data in enumerate(self.train_loader):
            cur_iter = self.opt.last_iter + 2 + iter_train
            cur_epoch = int((cur_iter - 1) / self.max_iter * self.opt.train_epoch) + 1
            self.lr_scheduler.step(cur_iter)
            cur_lr = self.lr_scheduler.get_lr()[0]

            input_var = torch.cat((data['left_img'], data['right_img']), 1).cuda()
            target_var = data['left_disp'].cuda()
            output = self.net(input_var)
                
            loss = self.loss_function(output, target_var)
            iter_loss = loss['iter_loss'] / self.opt.world_size

            self.optimizer.zero_grad()
            iter_loss.backward()
            reduce_gradients(self.net, self.opt.sync)
            self.optimizer.step()
            running_loss.update(loss)

            if cur_epoch == last_epoch + val_interval:
                if self.val_loader:
                    val_epe, val_d1 = self.val()
                    logger.info('epoch: {:>2d}/{:>2d}, val epe: {:>6.3f}, val d1: {:>6.3f}'.format(cur_epoch-1, self.opt.train_epoch, val_epe, val_d1))
                    if writer:
                        writer.add_scalar('val_epe', val_epe, cur_iter)
                        writer.add_scalar('val_d1', val_d1, cur_iter)
                    if val_d1 < best_val_d1:
                        best_val_d1 = val_d1
                        best_val_epe = val_epe
                        best_epoch = cur_epoch-1
                        if self.opt.rank == 0:
                            self.save_checkpoint({'epoch': cur_epoch-1,
                                                  'arch': self.opt.net_name,
                                                  'state_dict': self.net.state_dict(),
                                                  'iter': cur_iter}, 'model_best.pth')
                    self.net.train()
                last_epoch = cur_epoch

            if writer and cur_iter % self.opt.print_freq == 0:

                # loss
                for name, cur_loss in running_loss.metrics.items():
                    writer.add_scalar(name, cur_loss.mean(), cur_iter)

                # lr
                writer.add_scalar('lr', cur_lr, cur_iter)

                # disp
                for ki, cur_disp in enumerate(output['preds']):
                    disp_left_est = cur_disp[0, 0, :, :].cpu().detach().numpy()
                    disp_left_est = cv2.normalize(disp_left_est, None, 0, 255, cv2.NORM_MINMAX)
                    disp_left_est = disp_left_est.astype('uint8')
                    disp_left_est = cv2.applyColorMap(disp_left_est, cv2.COLORMAP_JET)
                    # writer.add_image('disp_left_est'+str(ki), disp_left_est[:, :, ::-1], cur_iter, dataformats='HWC')
                    writer.add_image('disp_left_est'+str(ki), disp_left_est[:, :, ::-1].transpose((2,0,1)), cur_iter)


                # imgL
                left_0 = np.squeeze(np.transpose(data['left_img'][0, :, :, :].cpu().detach(), (1, 2, 0))).numpy()
                left_0 = cv2.normalize(left_0, None, 0, 255, cv2.NORM_MINMAX)
                left_0 = left_0.astype('uint8')
                # writer.add_image('left_img', left_0, cur_iter, dataformats='HWC')
                writer.add_image('left_img', left_0.transpose((2,0,1)), cur_iter,)


                # imgR
                right_0 = np.squeeze(np.transpose(data['right_img'][0, :, :, :].cpu().detach(), (1, 2, 0))).numpy()
                right_0 = cv2.normalize(right_0, None, 0, 255, cv2.NORM_MINMAX)
                right_0 = right_0.astype('uint8')
                # writer.add_image('right_img', right_0, cur_iter, dataformats='HWC')
                writer.add_image('right_img', right_0.transpose((2,0,1)), cur_iter)

                # gt
                gt_disp = np.squeeze(data['left_disp'][0, 0].cpu().detach()).numpy()
                gt_disp = cv2.normalize(gt_disp, None, 0, 255, cv2.NORM_MINMAX)
                gt_disp = gt_disp.astype('uint8')
                gt_disp = cv2.applyColorMap(gt_disp, cv2.COLORMAP_JET)
                # writer.add_image('gt_disp', gt_disp[:, :, ::-1], cur_iter, dataformats='HWC')
                writer.add_image('gt_disp', gt_disp[:, :, ::-1].transpose((2,0,1)), cur_iter)

                logger.info('Iter: {:>4d}/{:>4d}, epoch: {:>2d}/{:>2d}, loss: {:>6.3f}, epe: {:>6.3f}'.format(cur_iter, self.max_iter, cur_epoch, self.opt.train_epoch, running_loss.mean('iter_loss'), running_loss.mean('cur_epe')))

        if self.opt.rank == 0:
            self.save_checkpoint({'epoch': self.opt.train_epoch,
                                  'arch': self.opt.net_name,
                                  'state_dict': self.net.state_dict(),
                                  'iter': cur_iter}, 'model_final.pth')
        logger.info('Finish training, cost time: {} h'.format((time.time()-train_start_time)/3600))
        if best_epoch != -1:
            logger.info('Best val epe : {:>6.3f}, best val d1 : {:>6.3f}  at epoch {}'.format(best_val_epe,best_val_d1,best_epoch))

    def test(self):
        self.net.eval()
        F = self.opt.get('F', 0)
        B = self.opt.get('B', 0)
        test_resize = self.opt.get('test_height', None)
        metrics = MetricLogger(10000)
        num_test_iter = len(self.test_loader)

        with torch.no_grad():
            for iter_test, sample_batched in enumerate(self.test_loader):
                input_var = torch.cat((sample_batched['left_img'], sample_batched['right_img']), 1).cuda()
                test_start_time = time.time()
                output = self.net(input_var)
                test_time = time.time() - test_start_time
                if iter_test % 10 == 0:
                    logger.info('iter {}/{},  test cost time : {} s'.format(iter_test, num_test_iter, test_time))

                pred_disp = output['preds']
                for i in range(pred_disp.shape[0]):
                    origin_h = sample_batched['origin_h'][i]
                    origin_w = sample_batched['origin_w'][i]
                    filename = sample_batched['file_name'][i]
                    if test_resize is None:
                        disp = pred_disp[i:i+1, :, :origin_h, :origin_w]
                        left_img = sample_batched['left_img'][i, :, :origin_h, :origin_w]
                        right_img = sample_batched['right_img'][i, :, :origin_h, :origin_w]
                    else:
                        disp = rescale_disp(pred_disp[i:i+1], origin_h, origin_w)
                        left_img = rescale_img(sample_batched['left_img'][i:i+1], origin_h, origin_w)
                        right_img = rescale_img(sample_batched['right_img'][i:i+1], origin_h, origin_w)

                    #cal epe and d1
                    if 'left_disp' in sample_batched:
                        left_disp_gt = sample_batched['left_disp'][i:i+1].cuda()
                    else:
                        left_disp_gt = None
                    if 'right_disp' in sample_batched:
                        right_disp_gt = sample_batched['right_disp'][i:i+1].cuda()
                    else:
                        right_disp_gt = None

                    metrics.update(disp_evaluation(disp, left_disp_gt, right_disp_gt, **self.opt.eval))

                    left_img_save = os.path.join(self.opt.savedir, filename[:-4] + '_L.png')
                    right_img_save = os.path.join(self.opt.savedir, filename[:-4] + '_R.png')
                    disp_color_save = os.path.join(self.opt.savedir, filename[:-4] + '_disp_color.png')
                    disp_png_save = os.path.join(self.opt.savedir, filename[:-4] + '_disp.png')
                    depth_npy_save = os.path.join(self.opt.savedir, filename[:-4] + '_depth.npy')
                    prob_npy_save = os.path.join(self.opt.savedir, filename[:-4] + '_prob.npy')
                    test_save_dir = os.path.dirname(left_img_save)
                    os.makedirs(test_save_dir, exist_ok=True)

                    disp = disp.cpu().detach().numpy().squeeze()

                    # save prob
                    if "probs" in output:
                        prob = output['probs'][i].cpu().detach().numpy()
                        np.save(prob_npy_save, prob)

                    # debug
                    # output disp numpy
                    disp_npy_save = os.path.join(self.opt.savedir, filename[:-4] + '_disp.npy')
                    np.save(disp_npy_save, disp)

                    if F != 0:
                        depth = F * B / disp
                        np.save(depth_npy_save, depth)

                    imgL = np.transpose(left_img.cpu().numpy().squeeze(), (1, 2, 0))
                    imgL = cv2.normalize(imgL, None, 0, 255, cv2.NORM_MINMAX)
                    imgL = imgL.astype('uint8')
                    skimage.io.imsave(left_img_save, imgL)

                    imgR = np.transpose(right_img.cpu().numpy().squeeze(), (1, 2, 0))
                    imgR = cv2.normalize(imgR, None, 0, 255, cv2.NORM_MINMAX)
                    imgR = imgR.astype('uint8')
                    skimage.io.imsave(right_img_save, imgR)

                    disp_color = cv2.normalize(disp, None, 0, 255, cv2.NORM_MINMAX)
                    disp_color = disp_color.astype('uint8')
                    disp_color = cv2.applyColorMap(disp_color, cv2.COLORMAP_JET)
                    cv2.imwrite(disp_color_save, disp_color)

                    #uint16 ��Χ[0,65535]
                    disp_uint16 = (disp * 256).astype('uint16')
                    disp_uint16[disp >= 256] = 65535
                    skimage.io.imsave(disp_png_save, disp_uint16)
                    # save_img = Image.fromarray(disp)
                    # save_img.save(disp_png_save)

        logger.info('Finish test.')
        if not metrics.empty():
            logger.info('test result :')
            for key in metrics.keys():
                logger.info('{} : {}'.format(key,metrics.mean(key)))


    def save_checkpoint(self, state_dict, filename='checkpoint.pth'):
        torch.save(state_dict, os.path.join(self.opt.train_output_directory, filename))

    def convert2caffe(self, save_name):
        test_height = self.opt.get('test_height', 576)
        test_width = self.opt.get('test_width', 960)
        from spring.nart.tools.pytorch import convert_mode, convert
        os.makedirs(os.path.dirname(save_name), exist_ok=True)
        self.net.eval()
        with convert_mode():
            convert.convert(self.net, [(6,test_height,test_width)], save_name, verbose=True)

    def convert2onnx(self, save_name):
        test_height = self.opt.get('test_height', 576)
        test_width = self.opt.get('test_width', 960)
        from spring.nart.tools.pytorch import convert_mode, convert
        import torch.onnx as torch_onnx
        os.makedirs(os.path.dirname(save_name), exist_ok=True)
        self.net.eval()
        with convert_mode():
            # convert.convert(self.net, [(6,test_height,test_width)], save_name, verbose=True)
            torch_onnx.export(self.net,torch.randn(1,6,test_height,test_width).cuda(),save_name+'.onnx',verbose=True)

    def load_state_keywise(self, model_path):
        model_dict = self.net.state_dict()
        resume_dict = torch.load(model_path, map_location='cpu')
        if 'state_dict' in resume_dict.keys():
            resume_dict = resume_dict['state_dict']

        key = list(resume_dict.keys())[0]
        if str(key).startswith('module.'):
            for k in model_dict.keys():
                model_dict[k] = resume_dict['module.'+k]
        else:
            self.net.load_state_dict(resume_dict)
        self.net.load_state_dict(model_dict)