import torch.multiprocessing as mp

# def demo(rank,world_size):
#     print('rank is: ',rank)

# def run_demo(demo_fn, world_size):
#     print('start...')
#     mp.spawn(demo_fn,
#              args=(world_size,),
#              nprocs=world_size,
#              join=True)
# if __name__ == "__main__":
#     run_demo(demo,3)
a = 1
b = 0 
if not a or  b:
    print(1)