import torch
import torch.nn.functional as F


class DispSmoothL1Loss(object):
    def __init__(self, maxdisp=192, weights=None, start_disp=0, maxpool=True):
        self.maxdisp = maxdisp
        self.weights = weights
        self.start_disp = start_disp
        if maxpool:
            # sparse disparity ==> max_pooling
            self.scale_func = F.adaptive_max_pool2d
        else:
            # dense disparity ==> avg_pooling
            self.scale_func = F.adaptive_avg_pool2d

    def loss_per_level(self, estDisp, gtDisp):
        N, C, H, W = estDisp.shape
        scaled_gtDisp = gtDisp
        scale = 1.0
        if gtDisp.shape[-2] != H or gtDisp.shape[-1] != W:
            # compute scale per level and scale gtDisp
            scale = gtDisp.shape[-1] / (W * 1.0)
            scaled_gtDisp = gtDisp / scale
            scaled_gtDisp = self.scale_func(scaled_gtDisp, (H, W))

        # mask for valid disparity
        # (start disparity, max disparity / scale)
        # Attention: the invalid disparity of KITTI is set as 0, be sure to mask it out
        mask = (scaled_gtDisp > self.start_disp) & (scaled_gtDisp < (self.maxdisp / scale))
        if mask.sum() < 1.0:
            # logger.info('SmoothL1 loss: there is no point\'s disparity is in ({},{})!'.format(self.start_disp,
            #                                                                             self.maxdisp / scale))
            loss = (torch.abs(estDisp - scaled_gtDisp) * mask.float()).mean()
            return loss

        # smooth l1 loss
        loss = F.smooth_l1_loss(estDisp[mask], scaled_gtDisp[mask], reduction='mean')
        return loss

    def __call__(self, preds, target):
        if not isinstance(preds, (list, tuple)):
            preds = [preds]

        if self.weights is None:
            self.weights = [1.0] * len(preds)

        # compute loss for per level
        loss_all_level = [self.loss_per_level(pred, target) for pred in preds]

        # re-weight loss per level
        epe_loss = 0
        for i, loss in enumerate(loss_all_level):
            epe_loss = epe_loss + self.weights[i] * loss

        return epe_loss


class Smooth_L1_Loss(torch.nn.Module):
    def __init__(self, maxdisp=192, start_disp=0, weights=None, maxpool=True, sm_weight=None, **kwargs):
        super(Smooth_L1_Loss, self).__init__()
        self.maxdisp = maxdisp
        self.weights = weights
        self.start_disp = start_disp
        self.sm_weight = sm_weight
        if maxpool:
            # sparse disparity ==> max_pooling
            self.scale_func = F.adaptive_max_pool2d
        else:
            # dense disparity ==> avg_pooling
            self.scale_func = F.adaptive_avg_pool2d

    def loss_per_level(self, estDisp, gtDisp):
        N, C, H, W = estDisp.shape
        scaled_gtDisp = gtDisp
        scale = 1.0
        if gtDisp.shape[-2] != H or gtDisp.shape[-1] != W:
            scale = gtDisp.shape[-1] / (W * 1.0)
            scaled_gtDisp = gtDisp / scale
            scaled_gtDisp = self.scale_func(scaled_gtDisp, (H, W))

        # mask for valid disparity
        # (start disparity, max disparity / scale)
        # Attention: the invalid disparity of KITTI is set as 0, be sure to mask it out
        mask = (scaled_gtDisp > self.start_disp) & (scaled_gtDisp < (self.maxdisp / scale))
        if mask.sum() < 1.0:
            loss = (torch.abs(estDisp - scaled_gtDisp) * mask.float()).mean()
        else:
            # smooth l1 loss
            loss = F.smooth_l1_loss(estDisp[mask], scaled_gtDisp[mask], reduction='mean')
        return loss

    def __call__(self, output, target):
        preds = output['preds']
        left_img = output.get('left_img', None)

        if not isinstance(preds, (list, tuple)):
            preds = [preds]

        if self.weights is None:
            self.weights = [1.0] * len(preds)
        assert len(self.weights) == len(preds), "len(weight) is {}, but len(preds) is {}".format(len(self.weights), len(preds))

        # compute loss for per level
        loss_all_level = [self.loss_per_level(pred, target) for pred in preds]

        # re-weight loss per level
        epe_loss = torch.FloatTensor(1).zero_().cuda()
        for i, loss in enumerate(loss_all_level):
            epe_loss = epe_loss + self.weights[i] * loss

        sm_loss = torch.FloatTensor(1).zero_().cuda()
        if self.sm_weight is not None:
            sm_loss = self.sm_weight * disp_smoothness(left_img, preds[0])

        cur_epe = self.loss_per_level(preds[0], target)

        return {'epe_loss': epe_loss,
                'sm_loss': sm_loss,
                'iter_loss': epe_loss + sm_loss,
                'cur_epe': cur_epe}