import torch
import torch.nn as nn
import torch.nn.functional as F
from networks.disp_prob_ops import disp2prob
from losses.common_loss import DispSmoothL1Loss
import numpy as np


class HD3_loss(object):
    def __init__(self, corr_range=[12, 3, 3, 3], maxdisp=-1, pool='max', weights=None, L1_weight=0, **kwargs):
        self.corr_range = corr_range
        self.epe = DispSmoothL1Loss()
        self.maxdisp = maxdisp
        self.L1_weight = L1_weight
        self.weights = weights if weights else np.ones_like(corr_range)
        self.criterion = nn.KLDivLoss(reduction='none').cuda()
        if pool=='max':
            self.scale_func = F.adaptive_max_pool2d
        elif pool=='mean':
            self.scale_func = F.adaptive_avg_pool2d

    def __call__(self, outputs, target):
        ms_probs = outputs['ms_prob']
        ms_preds = outputs['preds']
        level = len(ms_preds)
        B, _, H, W = target.shape

        KL_loss = 0
        L1_loss = 0

        for i in range(level):
            prob = ms_probs[i]
            scaled_target = target
            scale = 1.0

            if prob.shape[-2] != H or prob.shape[-1] != W:
                scale = prob.shape[-1] / (W * 1.0)
                scaled_target = target * scale
                scaled_target = self.scale_func(scaled_target, (prob.shape[-2], prob.shape[-1]))

            mask = scaled_target > 0
            if self.maxdisp > 0:
                mask = mask & (scaled_target < (self.maxdisp * scale))

            if mask.sum() < 1:
                logger.info('no disp small than {}'.format(self.maxdisp * scale))

            if i == 0:
                target_prob = disp2prob(scaled_target, mindisp=0, maxdisp=self.corr_range[i])
            if i > 0:
                last_disp = 2 * F.interpolate(ms_preds[i-1], scale_factor=2, mode='bilinear', align_corners=True)
                target_res = scaled_target - last_disp
                target_prob = disp2prob(target_res, mindisp=-self.corr_range[i], maxdisp=self.corr_range[i])

            if self.L1_weight != 0 :
                L1_loss += F.smooth_l1_loss(ms_preds[i][mask], scaled_target[mask], reduction='mean') * self.weights[i] * self.L1_weight
            KL_loss += (self.criterion(F.softmax(prob, dim=1), target_prob.detach())).mean() * self.weights[i]

        full_disp = 2 * F.interpolate(ms_preds[-1], scale_factor=2, mode='bilinear', align_corners=True)

        return {'iter_loss': L1_loss + KL_loss,
                'L1_loss': L1_loss,
                'KL_loss': KL_loss,
                'cur_epe': self.epe(full_disp, target)}