import torch
import torch.nn as nn
import math
import numpy as np
import torch.nn.functional as F
import logging
logger = logging.getLogger('global')


def D1_error(input_flow, target_flow, mask=None):
    if mask is None:
        mask = (target_flow > 0) & (target_flow < 192)
        mask.detach_()
        
    disp_abs = torch.abs(input_flow[mask]-target_flow[mask])
    correct = (disp_abs < 3) | (disp_abs < target_flow[mask]*0.05)
    return 1 - correct.sum().to(torch.float)/mask.sum()


def EPE(input_flow, target_flow, mask=None):
    if mask is None:
        mask = (target_flow > 0) & (target_flow < 192)
        mask.detach_()
        
    if mask.sum() < 1:
        return (torch.abs(input_flow - target_flow) * mask.float()).mean()
    return F.smooth_l1_loss(input_flow[mask], target_flow[mask], reduction='mean')


class MultiScaleLoss(nn.Module):
    def __init__(self, scales=7, downscale=2, weights=None, sm_weight=0):
        super(MultiScaleLoss, self).__init__()
        self.downscale = downscale
        self.weights = torch.Tensor(weights).cuda()
        self.sm_weight = sm_weight
        self.multiScales = [nn.MaxPool2d(self.downscale ** i, self.downscale ** i) for i in range(scales)]
        logger.info('train output downscale: {}'.format(self.downscale))

    def forward(self, output, target):
        left_disp = output['preds']
        left_img = output.get('left_img', None)
        EPE_loss = torch.FloatTensor(1).zero_().cuda()
        SM_loss = torch.FloatTensor(1).zero_().cuda()
        for i, disp_ in enumerate(left_disp):
            if self.weights[i] != 0:
                target_ = target
                if self.downscale != 1:
                    target_ = self.multiScales[i](target_)
                EPE_ = EPE(disp_, target_)
                EPE_loss += self.weights[i] * EPE_

                if i == 0 and self.sm_weight != 0:
                    SM_loss = disp_smoothness(left_img, disp_)

        return {'epe_loss': EPE_loss,
                'sm_loss': self.sm_weight * SM_loss,
                'iter_loss': EPE_loss + self.sm_weight * SM_loss,
                'cur_epe': EPE(left_disp[0], target)}

def gradient_x(img):
    gx = img[:, :, :, :-1] - img[:, :, :, 1:]  # NCHW
    return gx

def gradient_y(img):
    gy = img[:, :, :-1, :] - img[:, :, 1:, :]  # NCHW
    return gy


def disp_smoothness(img, disp):
    disp_gradients_x = gradient_x(disp)
    disp_gradients_y = gradient_y(disp)

    image_gradients_x = gradient_x(img)
    image_gradients_y = gradient_y(img)

    weights_x = torch.exp(-torch.mean(torch.abs(image_gradients_x), 1, keepdim=True))
    weights_y = torch.exp(-torch.mean(torch.abs(image_gradients_y), 1, keepdim=True))

    smoothness_x = torch.mean(torch.abs(disp_gradients_x * weights_x))
    smoothness_y = torch.mean(torch.abs(disp_gradients_y * weights_y))

    return smoothness_x + smoothness_y


class Loss_smooth(nn.Module):
    def __init__(self, loss='L1', sm_weight=0.01):
        super(Loss_smooth, self).__init__()
        self.loss = loss
        self.sm_weight = sm_weight

    def forward(self, left_img, left_disp, target):
        EPE_loss = EPE(left_disp, target)
        SM_loss = disp_smoothness(left_img, left_disp)
        return EPE_loss, self.sm_weight * SM_loss
