import torch
import torch.nn as nn
import torch.nn.functional as F
from networks.disp_prob_ops import disp2prob, prob2disp
import numpy as np


class Prob_loss(object):
    def __init__(self, maxdisp=192, weights=None, prob_weight=0, L1_weight=0, pool='max', focal_loss=False, **kwargs):
        self.maxdisp = maxdisp
        self.L1_weight = L1_weight
        self.prob_weight = prob_weight
        self.weights = weights
        self.focal_loss = focal_loss
        if pool == 'max':
            self.scale_func = F.adaptive_max_pool2d
        elif pool == 'mean':
            self.scale_func = F.adaptive_avg_pool2d

    def cal_prob_loss(self, prob, target, focal_coefficient=1):
        target_prob = disp2prob(target, mindisp=0, maxdisp=self.maxdisp-1)
        target_mask = (target > 0) & (target < self.maxdisp)
        prob = F.log_softmax(prob, dim=1)

        if self.focal_loss:
            target_prob = torch.clamp(target, min=0.0001, max=0.9999)
            weight = (1.0 - target_prob).pow(-focal_coefficient)
            pr_loss = -((target_prob * prob) * weight * target_mask.float()).sum(dim=1, keepdim=True).mean()
        else:
            pr_loss = -((target_prob * prob) * target_mask.float()).sum(dim=1, keepdim=True).mean()

        return pr_loss

    def rescale_disp(self, disp, shape):
        H, W = shape
        if disp.shape[-2] != H or disp.shape[-1] != W:
            disp = self.scale_func(disp, (H, W))

        return disp

    def cal_multiscale_loss(self, preds, target, weights):
        epe_loss = torch.FloatTensor(1).zero_().cuda()
        for i in range(len(preds)):
            B, C, H, W = preds[i].shape
            scale_gt = self.rescale_disp(target, (H, W))
            target_mask = (scale_gt > 0) & (scale_gt < self.maxdisp)

            if target_mask.sum() > 0:
                epe_loss += F.smooth_l1_loss(preds[i][target_mask], scale_gt[target_mask], reduction='mean') * weights[i]
        return epe_loss

    def epe(self, disp, target):
        target_mask = (target > 0) & (target < self.maxdisp)
        return torch.abs(disp[target_mask]-target[target_mask]).mean()

    def __call__(self, outputs, target):
        preds = outputs['preds']
        level = len(preds)
        weights = self.weights if self.weights else np.ones(level)
        pr_loss = torch.FloatTensor(1).zero_().cuda()
        epe_loss = torch.FloatTensor(1).zero_().cuda()

        full_disp = prob2disp(preds[0], normalize=True, mindisp=0)

        if self.prob_weight != 0:
            pr_loss = self.cal_prob_loss(preds[0], target) * self.prob_weight

        if self.L1_weight != 0:
            epe_loss = self.cal_multiscale_loss([full_disp] + preds[1:], target, weights) * self.L1_weight

        return {'iter_loss': pr_loss + epe_loss ,
                'prob_loss': pr_loss,
                'epe_loss': epe_loss,
                'cur_epe': self.epe(full_disp, target)}