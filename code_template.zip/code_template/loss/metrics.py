import torch
import warnings
from collections import abc as container_abcs
import torch

import logging
logger = logging.getLogger('global')


def inverse_warp(img, disp, padding_mode='zeros'):
    """
    Args:
        img (Tensor): the source image (where to sample pixels) -- [B, C, H, W]
        disp (Tensor): disparity map of the target image -- [B, 1, H, W]
        padding_mode (str): padding mode, default is zero padding
    Returns:
        projected_img (Tensor): source image warped to the target image -- [B, C, H, W]
    """
    b, _, h, w = disp.size()

    # [1, H, W]  copy 0-height for w times : y coord
    i_range = torch.arange(0, h).view(1, h, 1).expand(1, h, w).type_as(disp)
    # [1, H, W]  copy 0-width for h times  : x coord
    j_range = torch.arange(0, w).view(1, 1, w).expand(1, h, w).type_as(disp)

    pixel_coords = torch.stack((j_range, i_range), dim=1).type_as(disp).to(disp.device)  # [1, 2, H, W]
    batch_pixel_coords = pixel_coords.expand(b, 2, h, w).contiguous().view(b, 2, -1)  # [B, 2, H*W]

    X = batch_pixel_coords[:, 0, :] + disp.contiguous().view(b, -1)  # [B, H*W]
    Y = batch_pixel_coords[:, 1, :]

    X_norm = 2 * X / (w - 1) - 1
    Y_norm = 2 * Y / (h - 1) - 1

    # If grid has values outside the range of [-1, 1], the corresponding outputs are handled as defined by padding_mode.
    # Details please refer to torch.nn.functional.grid_sample
    if padding_mode == 'zeros':
        X_mask = ((X_norm > 1) + (X_norm < -1)).detach()
        X_norm[X_mask] = 2
        Y_mask = ((Y_norm > 1) + (Y_norm < -1)).detach()
        Y_norm[Y_mask] = 2

    pixel_coords = torch.stack([X_norm, Y_norm], dim=2)  # [B, H*W, 2]
    pixel_coords = pixel_coords.view(b, h, w, 2)  # [B, H, W, 2]

    projected_img = torch.nn.functional.grid_sample(img, pixel_coords, padding_mode=padding_mode)

    return projected_img


def calc_error(est_disp=None, gt_disp=None, lb=None, ub=None):
    """
    Args:
        est_disp (Tensor): in [BatchSize, Channel, Height, Width] or
            [BatchSize, Height, Width] or [Height, Width] layout
        gt_disp (Tensor): in [BatchSize, Channel, Height, Width] or
            [BatchSize, Height, Width] or [Height, Width] layout
        lb (scalar): the lower bound of disparity you want to mask out
        ub (scalar): the upper bound of disparity you want to mask out
    Output:
        dict: the error of 1px, 2px, 3px, 5px, in percent,
            range [0,100] and average error epe
    """
    error1 = torch.Tensor([0.])
    error2 = torch.Tensor([0.])
    error3 = torch.Tensor([0.])
    error5 = torch.Tensor([0.])
    epe = torch.Tensor([0.])

    if (not torch.is_tensor(est_disp)) or (not torch.is_tensor(gt_disp)):
        return {
            '1px': error1 * 100,
            '2px': error2 * 100,
            '3px': error3 * 100,
            '5px': error5 * 100,
            'epe': epe
        }

    assert torch.is_tensor(est_disp) and torch.is_tensor(gt_disp)
    assert est_disp.shape == gt_disp.shape

    est_disp = est_disp.clone().cpu()
    gt_disp = gt_disp.clone().cpu()

    mask = torch.ones(gt_disp.shape, dtype=torch.uint8)
    if lb is not None:
        mask = mask & (gt_disp > lb)
    if ub is not None:
        mask = mask & (gt_disp < ub)
    mask.detach_()
    if abs(mask.sum()) < 1.0:
        return {
            '1px': error1 * 100,
            '2px': error2 * 100,
            '3px': error3 * 100,
            '5px': error5 * 100,
            'epe': epe
        }

    gt_disp = gt_disp[mask]
    est_disp = est_disp[mask]

    abs_error = torch.abs(gt_disp - est_disp)
    total_num = mask.float().sum()

    error3 = 1 - torch.sum((abs_error < 3) | (abs_error < gt_disp*0.05)) / total_num

    error1 = torch.sum(torch.gt(abs_error, 1).float()) / total_num
    error2 = torch.sum(torch.gt(abs_error, 2).float()) / total_num
    # error3 = torch.sum(torch.gt(abs_error, 3).float()) / total_num
    error5 = torch.sum(torch.gt(abs_error, 5).float()) / total_num
    epe = abs_error.float().mean()

    return {'1px': error1 * 100,
            '2px': error2 * 100,
            '3px': error3 * 100,
            '5px': error5 * 100,
            'epe': epe}


def do_evaluation(est_disp, gt_disp, lb, ub):
    if torch.is_tensor(est_disp):
        est_disp = est_disp.clone().cpu()

    if torch.is_tensor(gt_disp):
        gt_disp = gt_disp.clone().cpu()

    return calc_error(est_disp, gt_disp, lb=lb, ub=ub)


def do_occlusion_evaluation(est_disp, ref_gt_disp, target_gt_disp, lb, ub):
    error_dict = {}
    if est_disp is None:
        warnings.warn('Estimated disparity map is None, expected given')
        return error_dict
    if ref_gt_disp is None:
        warnings.warn('Reference ground truth disparity map is None, expected given')
        return error_dict
    if target_gt_disp is None:
        warnings.warn('Target ground truth disparity map is None, expected given')
        return error_dict

    if torch.is_tensor(est_disp):
        est_disp = est_disp.clone().cpu()
    if torch.is_tensor(ref_gt_disp):
        ref_gt_disp = ref_gt_disp.clone().cpu()
    if torch.is_tensor(target_gt_disp):
        target_gt_disp = target_gt_disp.clone().cpu()

    warp_ref_gt_disp = inverse_warp(target_gt_disp.clone(), -ref_gt_disp.clone())
    theta = 1.0
    eps = 1e-6
    occlusion = ((torch.abs(warp_ref_gt_disp.clone() - ref_gt_disp.clone()) > theta) |
                 (torch.abs(warp_ref_gt_disp.clone()) < eps)).prod(dim=1, keepdim=True).type_as(ref_gt_disp)
    occlusion = occlusion.clamp(0, 1)

    occlusion_error_dict = calc_error(
        est_disp.clone() * occlusion.clone(),
        ref_gt_disp.clone() * occlusion.clone(),
        lb=lb, ub=ub
    )
    for key in occlusion_error_dict.keys():
        error_dict['occ_' + key] = occlusion_error_dict[key]

    not_occlusion = 1.0 - occlusion
    not_occlusion_error_dict = calc_error(
        est_disp.clone() * not_occlusion.clone(),
        ref_gt_disp.clone() * not_occlusion.clone(),
        lb=lb, ub=ub
    )
    for key in not_occlusion_error_dict.keys():
        error_dict['noc_' + key] = not_occlusion_error_dict[key]

    return error_dict


def disp_evaluation(disp, left_disp_gt, right_disp_gt, lower_bound=0, upper_bound=192, eval_occlusion=True):
    metircs = {}

    all_error_dict = do_evaluation(disp, left_disp_gt, lower_bound, upper_bound)

    for key in all_error_dict.keys():
        metircs['all_' + key] = all_error_dict[key]

    if eval_occlusion and (left_disp_gt is not None) and (right_disp_gt is not None):
        noc_occ_error_dict = do_occlusion_evaluation(disp, left_disp_gt, right_disp_gt, lower_bound, upper_bound)

        for key in noc_occ_error_dict.keys():
            metircs[key] = noc_occ_error_dict[key]

    return metircs
