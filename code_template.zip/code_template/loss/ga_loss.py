from libs.GANet.modules.GANet import MyLoss2
from losses.multiscaleloss import EPE
from losses.common_loss import DispSmoothL1Loss


class GaLoss(object):
    def __init__(self, weights=None, kitti=True, thresh=3, alpha=2, maxdisp=192):
        self.kitti = kitti
        self.weights = weights
        self.maxdisp = maxdisp
        self.thresh = thresh
        self.alpha = alpha
        self.other_evaluator = DispSmoothL1Loss(maxdisp=self.maxdisp, weights=self.weights[1:])
        
    def __call__(self, output, target):
        preds = output['preds']
        mask = (target > 0) & (target < self.maxdisp)
        mask.detach_()

        if self.kitti:
            last_evaluator = MyLoss2(thresh=thresh, alpha=alpha)
            last_loss = last_evaluator(preds[0][mask], target[mask]) * self.weights[0]
        else:
            last_loss = EPE(preds[0], target, mask)

        first_loss = self.other_evaluator(preds[1:], target)
        
        return {'first_loss': first_loss,
                'last_loss': last_loss,
                'iter_loss': first_loss + last_loss,
                'cur_epe': EPE(preds[0], target, mask)}

        